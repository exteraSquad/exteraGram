package com.chaquo.python;

import java.lang.reflect.*;


/** @deprecated Internal use in proxy.pxi */
public class PyInvocationHandler implements InvocationHandler {
    // These fields are also accessed directly from proxy.pxi.
    private PyObject type;
    private PyObject dict;

    public PyInvocationHandler(PyObject type) {
        this.type = type;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String methodName = method.getName();
        switch (methodName) {
            case "_chaquopyGetType":
                return type;
            case "_chaquopyGetDict":
                return dict;
            case "_chaquopySetDict":
                dict = (PyObject) args[0];
                return null;
            default:
                return invokeNative(proxy, methodName, args, method.getReturnType());
        }
    }

    /** Equivalent to {@code PyObject.fromJava(proxy).callAttrThrows(methodName, args)}
     * followed by {@code toJava(returnType)} on the result unless it's null, but much faster.
     * A null {@code args} array means no arguments. */
    private static native Object invokeNative(Object proxy, String methodName, Object[] args,
                                              Class<?> returnType) throws Throwable;
}
