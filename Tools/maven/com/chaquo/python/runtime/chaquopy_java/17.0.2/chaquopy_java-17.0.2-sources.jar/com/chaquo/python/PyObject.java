package com.chaquo.python;

import java.lang.ref.*;
import java.lang.reflect.*;
import java.util.*;
import org.jetbrains.annotations.*;

import static java.util.Objects.requireNonNull;

/** <p>Interface to a Python object.</p>
 *
 * <ul>
 * <li>Python {@code None} is represented by Java {@code null}. Other PyObjects can be
 * converted to their Java equivalents using {@link #toJava toJava()}.</li>
 *
 * <li>If a Python object is retrieved for which a PyObject already exists, the same
 * PyObject will be returned.</li>
 * </ul>
 *
 * <p>Unless otherwise specified, all methods in this class throw {@link PyException} on
 * failure.</p> */
public class PyObject extends AbstractMap<String,PyObject> implements AutoCloseable {
    // Maps the address of each Python object to the Ref of its current PyObject. Also guards
    // the mutable state of all Refs.
    private static final Map<Long, Ref> cache = new HashMap<>();

    /** @deprecated Internal use in conversion.pxi */
    public long addr;

    private final Ref ref;

    // Java objects which are referred to by Python objects that only this PyObject keeps alive.
    // While they're here, those Python references are weak, so a reference cycle which passes
    // through both languages can be collected by the Java garbage collector (see bridge.pxi).
    private Object[] pinned;

    /** @deprecated Internal use in bridge.pxi: the address of every Python object which Java
     * refers to, followed by the number of references, which may be owned by several Refs. */
    public static long[] heldReferences() {
        synchronized (cache) {
            int n = 0;
            for (Ref r = Ref.head; r != null; r = r.next) {
                n++;
            }
            long[] result = new long[n * 2];
            int i = 0;
            for (Ref r = Ref.head; r != null; r = r.next) {
                result[i++] = r.addr;
                result[i++] = r.count;
            }
            return result;
        }
    }

    /** @deprecated Internal use in bridge.pxi: the current PyObject of a Python object, or
     * null if there's none which is still reachable. */
    public static PyObject liveInstance(long addr) {
        synchronized (cache) {
            Ref ref = cache.get(addr);
            return (ref == null) ? null : ref.weak.get();
        }
    }

    /** @deprecated Internal use in conversion.pxi */
    public static PyObject getInstance(long addr) {
        if (addr == 0) return null;
        synchronized (cache) {
            Ref ref = cache.get(addr);
            if (ref != null) {
                // This will return null if the PyObject is unreachable but it hasn't been
                // released yet. In that case, the new PyObject below will replace it in the
                // cache, and the old one will still release its own references.
                PyObject po = ref.weak.get();
                if (po != null) {
                    // Every caller passes a new reference (see p2j_pyobject), but this
                    // PyObject already owns one. Releasing it now would require the GIL, so
                    // instead we take ownership of it, and release it with the others.
                    ref.count++;
                    return po;
                }
            }
            PyObject po = new PyObject(addr);
            cache.put(addr, po.ref);
            po.ref.add();
            return po;
        }
    }

    private PyObject(long addr) {
        this.addr = addr;
        ref = new Ref(this);
    }

    /** <p>Releases the reference to the Python object. Unless the object represents an
     * expensive resource, there's no need to call this method: the reference will be released
     * automatically after the PyObject is garbage-collected.</p>
     *
     * <p>After calling {@code close}, the PyObject can no longer be used. If there are no
     * other references to the underlying object, it may be destroyed by Python. If it
     * continues to exist and is retrieved by Java code again, a new PyObject will be
     * returned.</p>
     *
     * <p>Caution: any references to the same Python object elsewhere in your program will be
     * represented by the same PyObject, so they will all be invalidated by this call.</p> */
    public void close() {
        if (addr == 0) return;
        long count;
        synchronized (cache) {
            count = ref.take();
        }
        // Don't take the GIL within the cache lock, because most other methods do it in the
        // opposite order. If another thread closed this object at the same time, only one of
        // them will have a nonzero count.
        if (count != 0) {
            closeNative(ref.addr, count);
        }
        addr = 0;
    }
    private static native void closeNative(long addr, long count);

    /** <p>Owns the Python references of a PyObject, and releases them when it's closed or
     * garbage-collected.</p>
     *
     * <p>This replaces finalize(), which took the GIL separately for every object, on the
     * system finalizer thread. Instead, a single thread releases unreachable objects in
     * batches. A PhantomReference isn't enqueued until its referent can't even be reached
     * from another object's finalizer, so finalizers can still use PyObjects safely.</p> */
    private static final class Ref extends PhantomReference<PyObject> {
        private static final ReferenceQueue<PyObject> queue = new ReferenceQueue<>();
        private static final int BATCH_SIZE = 1024;

        // How often the releaser looks for reference cycles between Java and Python.
        private static final long SWEEP_INTERVAL_MS = 10_000;

        // A Reference which becomes unreachable is never enqueued, so all Refs which still
        // own references are kept in a linked list. Like all the other mutable state of this
        // class, it's guarded by `cache`.
        private static Ref head;
        private static Thread releaser;

        final long addr;
        final WeakReference<PyObject> weak;  // Used by getInstance to find the PyObject.
        long count = 1;  // Number of Python references owned.
        private Ref prev, next;

        Ref(PyObject po) {
            super(po, queue);
            addr = po.addr;
            weak = new WeakReference<>(po);
        }

        void add() {
            next = head;
            if (head != null) {
                head.prev = this;
            }
            head = this;

            if (releaser == null) {
                Thread thread = new Thread(new Runnable() {
                    @Override public void run() {
                        releaseLoop();
                    }
                }, "PyObject releaser");
                thread.setDaemon(true);
                thread.start();
                releaser = thread;  // Only once it's started, so a failure will be retried.
            }
        }

        /** Gives up ownership of this Ref's references, and returns how many there were. */
        long take() {
            clear();  // Prevent it from being enqueued, if it hasn't been already.
            long result = count;
            if (result != 0) {
                count = 0;
                if (prev != null) {
                    prev.next = next;
                } else {
                    head = next;
                }
                if (next != null) {
                    next.prev = prev;
                }
                prev = next = null;
                if (cache.get(addr) == this) {
                    cache.remove(addr);
                }
            }
            return result;
        }

        private static void releaseLoop() {
            long[] batch = new long[BATCH_SIZE * 2];  // Pairs of address and count.
            long nextSweep = System.nanoTime() + SWEEP_INTERVAL_MS * 1_000_000;
            while (true) {
                try {
                    long waitMs = (nextSweep - System.nanoTime()) / 1_000_000;
                    Reference<? extends PyObject> r = (waitMs > 0) ? queue.remove(waitMs) : null;
                    if (r == null) {
                        nextSweep = System.nanoTime() + SWEEP_INTERVAL_MS * 1_000_000;
                        sweepNative();
                        continue;
                    }
                    int n = 0;
                    synchronized (cache) {
                        do {
                            Ref ref = (Ref) r;
                            long count = ref.take();
                            if (count != 0) {
                                batch[n++] = ref.addr;
                                batch[n++] = count;
                            }
                        } while (n < batch.length && (r = queue.poll()) != null);
                    }
                    if (n != 0) {
                        releaseNative(batch, n / 2);
                    }
                } catch (InterruptedException ignored) {
                } catch (Throwable e) {
                    // Keep going, otherwise nothing would ever be released again.
                    e.printStackTrace();
                }
            }
        }
    }
    private static native void releaseNative(long[] batch, int n);
    private static native void sweepNative();

    /** <p>Converts the given Java object to a Python object. There's usually no need to call
     * this method: it will be called automatically by the methods of this class which take
     * {@code Object} parameters.</p>
     *
     * <p>For details of how Java objects are represented in Python, see the
     * <a href="../../../../python.html#data-types-overview">Python API</a>.</p> */
    public static PyObject fromJava(Object o) {
        return getInstance(fromJavaNative(o));
    }
    private static native long fromJavaNative(Object o);

    /** <p>Converts the Python object to the given Java type.</p>
     *
     * <p>If {@code klass} is a primitive type such as {@code int}, or an immutable value type
     * such as {@code Integer} or {@code String}, and the Python object is compatible with it,
     * an equivalent Java object will be returned. However, it's more efficient to use the
     * specific methods like {@link #toInt}, {@link #toString}, etc.</p>
     *
     * <p>If {@code klass} is an array type, and the Python object is a <a
     * href="https://docs.python.org/3/glossary.html#term-sequence">sequence</a>, then a copy
     * of the sequence will be returned as a new array. In general, each element will be
     * converted as if {@code toJava} was called on it recursively. However, when converting a
     * Python {@code bytes} or {@code bytearray} object to a Java {@code byte[]} array, there
     * is an unsigned-to-signed conversion: Python values 128 to 255 will be mapped to Java
     * values -128 to -1.</p>
     *
     * <p>If the Python object is a <a href="../../../../python.html#java.jclass">jclass</a> or
     * <a href="../../../../python.html#java.jarray">jarray</a> object which is compatible with
     * {@code klass}, the underlying Java object will be returned.</p>
     *
     * <p>Otherwise, a {@code ClassCastException} will be thrown.</p> */
    public native @NotNull <T> T toJava(@NotNull Class<T> klass);


    // === Primitive conversions =============================================

    /** Converts a Python {@code bool} to a Java {@code boolean}.
     * @throws ClassCastException if the Python object is not compatible */
    public native boolean toBoolean();

    /** Converts a Python {@code int} to a Java {@code byte}.
     * @throws ClassCastException if the Python object is not compatible */
    public native byte toByte();

    /** Converts a 1-character Python string to a Java {@code char}.
     * @throws ClassCastException if the Python object is not compatible */
    public native char toChar();

    /** Converts a Python {@code int} to a Java {@code short}.
     * @throws ClassCastException if the Python object is not compatible */
    public native short toShort();

    /** Converts a Python {@code int} to a Java {@code int}.
     * @throws ClassCastException if the Python object is not compatible */
    public native int toInt();

    /** Converts a Python {@code int} to a Java {@code long}.
     * @throws ClassCastException if the Python object is not compatible */
    public native long toLong();

    /** Converts a Python {@code float} or {@code int}  to a Java {@code float}.
     * @throws ClassCastException if the Python object is not compatible */
    public native float toFloat();

    /** Converts a Python {@code float} or {@code int} to a Java {@code double}.
     * @throws ClassCastException if the Python object is not compatible */
    public native double toDouble();


    // === Container views ===================================================

    /** <p>Returns a view of the Python object as a list. The view is backed by the object, so
     * changes to the object are reflected in the view, and vice-versa.</p>
     *
     * <p>To add Java objects to the Python container through the view, first convert them
     * using {@link #fromJava fromJava()}.</p>
     *
     * @throws UnsupportedOperationException if the Python object does not implement the
     * methods {@code __getitem__} and {@code __len__}. */
    public @NotNull List<PyObject> asList() { return new PyList(this); }

    /** <p>Returns a view of the Python object as a map. The view is backed by the object, so
     * changes to the object are reflected in the view, and vice-versa.</p>
     *
     * <p>PyObject already implements the {@code Map} interface, but that is for attribute
     * access (Python "{@code .}" syntax), whereas the {@code Map} returned by this method is
     * for container access (Python "{@code []}" syntax).</p>
     *
     * <p>To add Java objects to the Python container through the view, first convert them
     * using {@link #fromJava fromJava()}.</p>
     *
     * @throws UnsupportedOperationException if the Python object does not implement the
     * methods {@code __contains__}, {@code __getitem__}, {@code __iter__} and {@code __len__}. */
    public @NotNull Map<PyObject, PyObject> asMap() { return new PyMap(this); }

    /** <p>Returns a view of the Python object as a set. The view is backed by the object, so
     * changes to the object are reflected in the view, and vice-versa.</p>
     *
     * <p>To add Java objects to the Python container through the view, first convert them
     * using {@link #fromJava fromJava()}.</p>
     *
     * @throws UnsupportedOperationException if the Python object does not implement the
     * methods {@code __contains__}, {@code __iter__} and {@code __len__}. */
    public @NotNull Set<PyObject> asSet() { return new PySet(this); }


    // === Miscellaneous =====================================================

    /** Equivalent to Python {@code id()}. */
    public native long id();

    /** Equivalent to Python {@code type()}. */
    public @NotNull PyObject type() {
        return requireNonNull(getInstance(typeNative()));
    }
    private native long typeNative();

    /** Equivalent to Python {@code ()} syntax. Arguments will be converted as described at
     * {@link #fromJava fromJava()}. Keyword arguments can be passed using instances of {@link
     * Kwarg} at the end of the argument list. */
    public PyObject call(Object... args) {
        try {
            return callThrows(args);
        } catch (PyException e) {
            throw e;
        } catch (Throwable e) {
            throw new PyException(e);
        }
    }

    /** Same as {@link #call call()}, except it directly passes any Java exception thrown
     * by the Python code. */
    public PyObject callThrows(Object... args) throws Throwable {
        return getInstance(callThrowsNative(args));
    }
    private native long callThrowsNative(Object... args) throws Throwable;

    /** Same as {@link #get get}{@code (key).}{@link #call call}{@code (args)}, except it
     * throws a {@link PyException} if the attribute does not exist. */
    public PyObject callAttr(@NotNull String key, Object... args) {
        try {
            return callAttrThrows(key, args);
        } catch (PyException e) {
            throw e;
        } catch (Throwable e) {
            throw new PyException(e);
        }
    }

    /** Same as {@link #callAttr callAttr()}, except it directly passes any Java exception
     * thrown by the Python code. */
    public PyObject callAttrThrows(@NotNull String key, Object... args) throws Throwable {
        return getInstance(callAttrThrowsNative(key, args));
    }
    private native long callAttrThrowsNative(String key, Object... args) throws Throwable;

    /** @deprecated internal use in files generated by static_proxy.py */
    public static PyObject _chaquopyCall(StaticProxy sp, String name, Object... args) {
        try {
            return PyObject.fromJava(sp).callAttrThrows(name, args);
        } catch (RuntimeException | Error e) {
            throw e;
        } catch (Throwable e) {
            throw new UndeclaredThrowableException(e);
        }
    }


    // ==== Attributes =======================================================

    /** <p>Attempts to remove all attributes returned by {@link #keySet()}. See notes on
     * {@link #isEmpty}.</p> */
    @Override public void clear() { super.clear(); }

    /** Equivalent to {@link #keySet()}{@code .isEmpty()}. Because {@code keySet} usually
     * includes the object's class attributes, {@code isEmpty} will never return true even
     * after calling {@link #clear}, unless the object has a custom {@code __dir__} method. */
    @Override public boolean isEmpty() { return super.isEmpty(); }

    /** Equivalent to Python {@code hasattr()}. */
    @Override public boolean containsKey(@NotNull Object key) {
        return containsKeyNative((String)key);
    }
    private native boolean containsKeyNative(String key);

    /** Returns whether any attribute has the given value. The value will be converted as
     * described at {@link #fromJava fromJava()}. */
    @Override public boolean containsValue(Object o) {
        return super.containsValue(fromJava(o));
    }

    /** Equivalent to Python {@code getattr()}. In accordance with the {@code Map} interface,
     * when the attribute does not exist, this method returns {@code null} rather than
     * throwing an exception. To distinguish this from an attribute with a value of {@code
     * None}, use {@link #containsKey containsKey()}. */
    @Override public PyObject get(@NotNull Object key) {
        return getInstance(getNative((String)key));
    }
    private native long getNative(String key);

    /** Equivalent to Python {@code setattr()}. */
    @Override public PyObject put(@NotNull String key, PyObject value) {
        return put(key, (Object)value);
    }

    /** Equivalent to Python {@code setattr()}. The value will be converted as described at
     * {@link #fromJava fromJava()}.*/
    public PyObject put(@NotNull String key, Object value) {
        return getInstance(putNative(key, value));
    }
    private native long putNative(String key, Object value);

    /** <p>Equivalent to Python {@code delattr()}. This means it can only remove attributes of
     * the object itself, even though {@link #keySet()} usually includes the object's class
     * attributes as well.</p>
     *
     * <p>In accordance with the {@code Map} interface, when the attribute does not exist, this
     * method returns {@code null} rather than throwing an exception.</p> */
    @Override public PyObject remove(@NotNull Object key) {
        return getInstance(removeNative((String)key));
    }
    private native long removeNative(String key);

    /** <p>Equivalent to Python {@code dir()}. Unless the object has a custom {@code __dir__}
     * method, this means the result will include attributes from the object's class as well
     * as the object itself.</p>
     *
     * <p>The returned set is backed by the Python object, so changes to the object are
     * reflected in the set, and vice-versa. If the object is modified while an iteration over
     * the set is in progress (except through the iterator's own {@code remove} operation), the
     * results of the iteration are undefined. The set supports element removal, but see the
     * notes on {@link #remove remove()}. It does not support the {@code add} or {@code addAll}
     * operations.</p> */
    @Override public @NotNull Set<String> keySet() { return super.keySet(); }

    /** See notes on {@link #keySet()}. */
    @Override public @NotNull Set<Entry<String, PyObject>> entrySet() {
        return new AbstractSet<Entry<String, PyObject>>() {
            @Override public int size() { return dir().size(); }

            @Override public @NotNull Iterator<Entry<String, PyObject>> iterator() {
                return new Iterator<Entry<String, PyObject>>() {
                    List<String> keys = dir();
                    int i = 0;

                    @Override public boolean hasNext() {
                        return i < keys.size();
                    }

                    @Override public Entry<String, PyObject> next() {
                        if (! hasNext()) throw new NoSuchElementException();
                        Entry<String, PyObject> entry = new Entry<String, PyObject>() {
                            String key = keys.get(i);
                            @Override public String getKey()     { return key; }
                            @Override public PyObject getValue() { return get(key); }
                            @Override public PyObject setValue(PyObject newValue) {
                                return put(key, newValue);
                            }
                        };
                        i += 1;
                        return entry;
                    }

                    @Override public void remove() {
                        PyObject.this.remove(keys.get(i-1));
                    }
                };
            }
        };
    }

    private native List<String> dir();


    // === Object methods ====================================================

    /** Equivalent to Python {@code ==} operator. The given object will be converted as
     * described at {@link #fromJava fromJava()} */
    @Override public native boolean equals(Object that);

    /** Equivalent to Python {@code str()}. */
    @Override public native @NotNull String toString();

    /** Equivalent to Python {@code repr()}. */
    public native @NotNull String repr();

    /** Equivalent to Python {@code hash()}. */
    @Override public native int hashCode();
}
