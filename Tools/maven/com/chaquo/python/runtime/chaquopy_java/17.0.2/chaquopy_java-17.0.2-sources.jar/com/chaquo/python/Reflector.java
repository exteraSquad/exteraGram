package com.chaquo.python;

import java.lang.ref.*;
import java.lang.reflect.*;
import java.util.*;

/** This class is critical for performance, as it allows us to call the reflection API mostly
 * from Java, and only create Python class members on demand.
 *
 * @deprecated internal use in class.pxi. */
public class Reflector {

    private static final DeniedMethod[] DENIED_METHODS = {
        new DeniedMethod(
            "android.widget.TextView", "setTextColor", Void.TYPE, Long.TYPE
        ),
    };

    private final Class<?> klass;
    private Map<String,Member> methods;               // We target Java 7, so we can't use
    private Map<String,List<Member>> multipleMethods; // java.lang.reflect.Executable.
    private Map<String,Member> methodsAll;
    private Map<String,List<Member>> multipleMethodsAll;
    private Map<String,Member> propertyGetters;
    private Map<String,List<Member>> multiplePropertyGetters;
    private Map<String,Member> staticPropertyGetters;
    private Map<String,List<Member>> multipleStaticPropertyGetters;
    private Map<String,Member> propertyGettersAll;
    private Map<String,List<Member>> multiplePropertyGettersAll;
    private Map<String,Member> staticPropertyGettersAll;
    private Map<String,List<Member>> multipleStaticPropertyGettersAll;
    private Map<String,Member> propertySetters;
    private Map<String,List<Member>> multiplePropertySetters;
    private Map<String,Member> staticPropertySetters;
    private Map<String,List<Member>> multipleStaticPropertySetters;
    private Map<String,Member> propertySettersAll;
    private Map<String,List<Member>> multiplePropertySettersAll;
    private Map<String,Member> staticPropertySettersAll;
    private Map<String,List<Member>> multipleStaticPropertySettersAll;
    private Map<String,Field> fields;
    private Map<String,Field> fieldsAll;
    private Map<String,Class<?>> classes;
    private Map<String,Class<?>> classesAll;

    // The keys are weak so that classes from a dynamically-loaded ClassLoader can be unloaded
    // (see class_loader.pxi). The values must be weak as well, because a WeakHashMap entry
    // whose value refers to its own key will never be removed. This is not a problem in
    // practice, because Python's own class objects hold a strong reference to their Reflector
    // for as long as they exist.
    private static final Map<Class<?>, WeakReference<Reflector>> instances = new WeakHashMap<>();

    public static synchronized Reflector getInstance(Class<?> klass) {
        WeakReference<Reflector> ref = instances.get(klass);
        Reflector reflector = (ref == null) ? null : ref.get();
        if (reflector != null) {
            return reflector;
        }
        reflector = new Reflector(klass);
        instances.put(klass, new WeakReference<>(reflector));
        return reflector;
    }

    private Reflector(Class<?> klass) {
        this.klass = klass;
    }

    public synchronized String[] dir() {
        return dir(false);
    }

    public synchronized String[] dirAll() {
        return dir(true);
    }

    public synchronized String[] dir(boolean accessAll) {
        if (accessAll) {
            if (methodsAll == null) loadMethods(true);
            if (fieldsAll == null) loadFields(true);
            if (classesAll == null) loadClasses(true);
        } else {
            if (methods == null) loadMethods(false);
            if (fields == null) loadFields(false);
            if (classes == null) loadClasses(false);
        }
        Set<String> names = new HashSet<>();
        names.addAll((accessAll ? methodsAll : methods).keySet());
        names.addAll((accessAll ? multipleMethodsAll : multipleMethods).keySet());
        names.addAll((accessAll ? fieldsAll : fields).keySet());
        names.addAll((accessAll ? classesAll : classes).keySet());
        return names.toArray(new String[0]);
    }

    public synchronized Member[] getMethods(String name) {
        return getMethods(name, false);
    }

    public synchronized Member[] getMethodsAll(String name) {
        return getMethods(name, true);
    }

    public synchronized Member[] getMethods(String name, boolean accessAll) {
        if (accessAll) {
            if (methodsAll == null) loadMethods(true);
        } else {
            if (methods == null) loadMethods(false);
        }
        Map<String,Member> methodsMap = accessAll ? methodsAll : methods;
        Map<String,List<Member>> multipleMethodsMap = accessAll ? multipleMethodsAll : multipleMethods;
        List<Member> list = multipleMethodsMap.get(name);
        if (list != null) {
            return list.toArray(new Member[0]);
        }
        Member method = methodsMap.get(name);
        if (method != null) {
            return new Member[] { method };
        }
        return null;
    }

    public synchronized Member[] getPropertyGetters(String name, boolean accessAll, int staticMode) {
        if (accessAll) {
            if (propertyGettersAll == null) loadMethods(true);
        } else {
            if (propertyGetters == null) loadMethods(false);
        }
        return getPropertyMethods(
            name, accessAll, staticMode,
            propertyGetters, multiplePropertyGetters,
            staticPropertyGetters, multipleStaticPropertyGetters,
            propertyGettersAll, multiplePropertyGettersAll,
            staticPropertyGettersAll, multipleStaticPropertyGettersAll
        );
    }

    public synchronized Member[] getPropertySetters(String name, boolean accessAll, int staticMode) {
        if (accessAll) {
            if (propertySettersAll == null) loadMethods(true);
        } else {
            if (propertySetters == null) loadMethods(false);
        }
        return getPropertyMethods(
            name, accessAll, staticMode,
            propertySetters, multiplePropertySetters,
            staticPropertySetters, multipleStaticPropertySetters,
            propertySettersAll, multiplePropertySettersAll,
            staticPropertySettersAll, multipleStaticPropertySettersAll
        );
    }

    private Member[] getPropertyMethods(
            String name, boolean accessAll, int staticMode,
            Map<String,Member> methodsMapLocal, Map<String,List<Member>> multipleMethodsMapLocal,
            Map<String,Member> staticMethodsMapLocal, Map<String,List<Member>> multipleStaticMethodsMapLocal,
            Map<String,Member> methodsMapAll, Map<String,List<Member>> multipleMethodsMapAll,
            Map<String,Member> staticMethodsMapAll, Map<String,List<Member>> multipleStaticMethodsMapAll) {
        Map<String,Member> methodsMap;
        Map<String,List<Member>> multipleMethodsMap;
        if (accessAll) {
            methodsMap = (staticMode == 1) ? staticMethodsMapAll : methodsMapAll;
            multipleMethodsMap = (staticMode == 1) ? multipleStaticMethodsMapAll : multipleMethodsMapAll;
        } else {
            methodsMap = (staticMode == 1) ? staticMethodsMapLocal : methodsMapLocal;
            multipleMethodsMap = (staticMode == 1) ? multipleStaticMethodsMapLocal : multipleMethodsMapLocal;
        }
        List<Member> list = multipleMethodsMap.get(name);
        if (list != null) {
            return list.toArray(new Member[0]);
        }
        Member method = methodsMap.get(name);
        if (method != null) {
            return new Member[] { method };
        }
        return null;
    }

    private void loadMethods(boolean accessAll) {
        Map<String,Member> methodsMap = new HashMap<>();
        Map<String,List<Member>> multipleMethodsMap = new HashMap<>();
        Map<String,Member> propertyGettersMap = new HashMap<>();
        Map<String,List<Member>> multiplePropertyGettersMap = new HashMap<>();
        Map<String,Member> staticPropertyGettersMap = new HashMap<>();
        Map<String,List<Member>> multipleStaticPropertyGettersMap = new HashMap<>();
        Map<String,Member> propertySettersMap = new HashMap<>();
        Map<String,List<Member>> multiplePropertySettersMap = new HashMap<>();
        Map<String,Member> staticPropertySettersMap = new HashMap<>();
        Map<String,List<Member>> multipleStaticPropertySettersMap = new HashMap<>();
        for (Constructor<?> c : klass.getDeclaredConstructors()) {
            if (includeMember(c, accessAll)) {
                prepareAccessible(c, accessAll);
                loadMethod(methodsMap, multipleMethodsMap, c, "<init>");
            }
        }
        for (Method m : getDeclaredMethods()) {
            if (isDeniedMethod(m)) {
                continue;
            }
            if (includeMember(m, accessAll)) {
                prepareAccessible(m, accessAll);
                loadMethod(methodsMap, multipleMethodsMap, m, m.getName());
                loadPropertyMethods(
                    m,
                    propertyGettersMap, multiplePropertyGettersMap,
                    staticPropertyGettersMap, multipleStaticPropertyGettersMap,
                    propertySettersMap, multiplePropertySettersMap,
                    staticPropertySettersMap, multipleStaticPropertySettersMap
                );
            }
        }
        if (accessAll) {
            methodsAll = methodsMap;
            multipleMethodsAll = multipleMethodsMap;
            propertyGettersAll = propertyGettersMap;
            multiplePropertyGettersAll = multiplePropertyGettersMap;
            staticPropertyGettersAll = staticPropertyGettersMap;
            multipleStaticPropertyGettersAll = multipleStaticPropertyGettersMap;
            propertySettersAll = propertySettersMap;
            multiplePropertySettersAll = multiplePropertySettersMap;
            staticPropertySettersAll = staticPropertySettersMap;
            multipleStaticPropertySettersAll = multipleStaticPropertySettersMap;
        } else {
            methods = methodsMap;
            multipleMethods = multipleMethodsMap;
            propertyGetters = propertyGettersMap;
            multiplePropertyGetters = multiplePropertyGettersMap;
            staticPropertyGetters = staticPropertyGettersMap;
            multipleStaticPropertyGetters = multipleStaticPropertyGettersMap;
            propertySetters = propertySettersMap;
            multiplePropertySetters = multiplePropertySettersMap;
            staticPropertySetters = staticPropertySettersMap;
            multipleStaticPropertySetters = multipleStaticPropertySettersMap;
        }
    }

    private boolean isDeniedMethod(Method method) {
        for (DeniedMethod deniedMethod : DENIED_METHODS) {
            if (deniedMethod.matches(method)) {
                return true;
            }
        }
        return false;
    }

    private static class DeniedMethod {
        private final String className;
        private final String methodName;
        private final Class<?> returnType;
        private final Class<?>[] parameterTypes;

        DeniedMethod(String className, String methodName, Class<?> returnType,
                     Class<?>... parameterTypes) {
            this.className = className;
            this.methodName = methodName;
            this.returnType = returnType;
            this.parameterTypes = parameterTypes;
        }

        boolean matches(Method method) {
            return className.equals(method.getDeclaringClass().getName())
                    && methodName.equals(method.getName())
                    && returnType == method.getReturnType()
                    && Arrays.equals(parameterTypes, method.getParameterTypes());
        }
    }

    private Collection<Method> getDeclaredMethods() {
        try {
            return Arrays.asList(klass.getDeclaredMethods());
        } catch (NoClassDefFoundError ignored) {}

        // On Android, getDeclaredMethods fails if any method signature refers to a class that
        // cannot be loaded
        // (https://android.googlesource.com/platform/libcore/+/refs/tags/android-5.0.0_r7/libart/src/main/java/java/lang/Class.java#771).
        // I don't know any perfect workaround for this, but there are a few ways we can
        // discover at least some of the methods.
        Set<Method> result = new HashSet<>();

        // Discover public methods: only works on API level 21 and higher.
        try {
            for (Method m : klass.getMethods()) {
                if (m.getDeclaringClass() == klass) {
                    try {
                        m.getReturnType();
                        m.getParameterTypes();
                        result.add(m);
                    } catch (NoClassDefFoundError ignored) {}
                }
            }
        } catch (NoClassDefFoundError ignored) {}

        // Discover inherited methods overridden by this class.
        for (Class<?> c = klass.getSuperclass(); c != null; c = c.getSuperclass()) {
            for (Method inherited : Reflector.getInstance(c).getDeclaredMethods()) {
                try {
                    result.add(klass.getDeclaredMethod(inherited.getName(),
                                                       inherited.getParameterTypes()));
                } catch (NoSuchMethodException ignored) {}
            }
        }

        return result;
    }

    private void loadMethod(Map<String,Member> methodsMap, Map<String,List<Member>> multipleMethodsMap,
                            Member m, String name) {
        List<Member> list;
        Member mExisting = methodsMap.remove(name);
        if (mExisting != null) {
            list = new ArrayList<>();
            list.add(mExisting);
            list.add(m);
            multipleMethodsMap.put(name, list);
        } else if ((list = multipleMethodsMap.get(name)) != null) {
            list.add(m);
        } else {
            methodsMap.put(name, m);
        }
    }

    private void loadPropertyMethods(
            Method m,
            Map<String,Member> propertyGettersMap, Map<String,List<Member>> multiplePropertyGettersMap,
            Map<String,Member> staticPropertyGettersMap, Map<String,List<Member>> multipleStaticPropertyGettersMap,
            Map<String,Member> propertySettersMap, Map<String,List<Member>> multiplePropertySettersMap,
            Map<String,Member> staticPropertySettersMap, Map<String,List<Member>> multipleStaticPropertySettersMap) {
        boolean isStatic = Modifier.isStatic(m.getModifiers());

        for (String getterName : propertyGetterNames(m)) {
            loadMethod(propertyGettersMap, multiplePropertyGettersMap, m, getterName);
            if (isStatic) {
                loadMethod(staticPropertyGettersMap, multipleStaticPropertyGettersMap, m, getterName);
            }
        }

        for (String setterName : propertySetterNames(m)) {
            loadMethod(propertySettersMap, multiplePropertySettersMap, m, setterName);
            if (isStatic) {
                loadMethod(staticPropertySettersMap, multipleStaticPropertySettersMap, m, setterName);
            }
        }
    }

    private List<String> propertyGetterNames(Method m) {
        String name = m.getName();
        List<String> result = new ArrayList<>();
        if ((name.startsWith("get")) && (name.length() > 3) && (m.getParameterTypes().length == 0)) {
            if (m.getReturnType() != Void.TYPE) {
                String suffix = name.substring(3);
                addPropertyAlias(result, decapitalizePropertyName(suffix));
                if (isBooleanType(m.getReturnType())) {
                    addPropertyAlias(result, booleanPropertyAliasName(suffix));
                }
            }
        }
        if ((name.startsWith("is")) && (name.length() > 2) && (m.getParameterTypes().length == 0) &&
                isBooleanType(m.getReturnType())) {
            addPropertyAlias(result, decapitalizePropertyName(name.substring(2)));
            addPropertyAlias(result, name);
        }
        return result;
    }

    private List<String> propertySetterNames(Method m) {
        String name = m.getName();
        List<String> result = new ArrayList<>();
        if ((name.startsWith("set")) && (name.length() > 3) && (m.getParameterTypes().length != 0)) {
            String suffix = name.substring(3);
            addPropertyAlias(result, decapitalizePropertyName(suffix));
            if (isBooleanType(m.getParameterTypes()[0])) {
                addPropertyAlias(result, booleanPropertyAliasName(suffix));
            }
        }
        return result;
    }

    private void addPropertyAlias(List<String> aliases, String alias) {
        if ((alias != null) && (! aliases.contains(alias))) {
            aliases.add(alias);
        }
    }

    private boolean isBooleanType(Class<?> type) {
        return (type == Boolean.TYPE) || (type == Boolean.class);
    }

    private String booleanPropertyAliasName(String suffix) {
        if (suffix.isEmpty()) {
            return null;
        }
        if (suffix.startsWith("Is") && (suffix.length() > 2) &&
                Character.isUpperCase(suffix.charAt(2))) {
            return decapitalizePropertyName(suffix);
        }
        return "is" + suffix;
    }

    private String decapitalizePropertyName(String suffix) {
        if (suffix.isEmpty()) {
            return null;
        }
        return Character.toLowerCase(suffix.charAt(0)) + suffix.substring(1);
    }

    public synchronized Field getField(String name) {
        return getField(name, false);
    }

    public synchronized Field getFieldAll(String name) {
        return getField(name, true);
    }

    public synchronized Field getField(String name, boolean accessAll) {
        if (accessAll) {
            if (fieldsAll == null) loadFields(true);
            return fieldsAll.get(name);
        } else {
            if (fields == null) loadFields(false);
            return fields.get(name);
        }
    }

    private void loadFields(boolean accessAll) {
        Map<String,Field> fieldsMap = new HashMap<>();
        for (Field f : getDeclaredFields()) {
            if (accessAll || isAccessible(f)) {
                prepareAccessible(f, accessAll);
                fieldsMap.put(f.getName(), f);
            }
        }
        if (accessAll) {
            fieldsAll = fieldsMap;
        } else {
            fields = fieldsMap;
        }
    }

    private Collection<Field> getDeclaredFields() {
        try {
            return Arrays.asList(klass.getDeclaredFields());
        } catch (NoClassDefFoundError ignored) {}

        // See comment in getDeclaredMethods.
        Set<Field> result = new HashSet<>();

        // Discover public fields: this doesn't work on any version of Android as far as I know,
        // but we might as well keep it in case that changes.
        try {
            for (Field f : klass.getFields()) {
                if (f.getDeclaringClass() == klass) {
                    try {
                        f.getType();
                        result.add(f);
                    } catch (NoClassDefFoundError ignored) {}
                }
            }
        } catch (NoClassDefFoundError ignored) {}

        return result;
    }

    public synchronized Class<?> getNestedClass(String name) {
        return getNestedClass(name, false);
    }

    public synchronized Class<?> getNestedClassAll(String name) {
        return getNestedClass(name, true);
    }

    public synchronized Class<?> getNestedClass(String name, boolean accessAll) {
        if (accessAll) {
            if (classesAll == null) loadClasses(true);
            return classesAll.get(name);
        } else {
            if (classes == null) loadClasses(false);
            return classes.get(name);
        }
    }

    private void loadClasses(boolean accessAll) {
        Map<String,Class<?>> classesMap = new HashMap<>();
        for (Class<?> k : klass.getDeclaredClasses()) {
            if (accessAll || isAccessible(k.getModifiers())) {
                String simpleName = k.getSimpleName();
                if (simpleName.isEmpty()) continue;   // Anonymous class
                classesMap.put(simpleName, k);
            }
        }
        if (accessAll) {
            classesAll = classesMap;
        } else {
            classes = classesMap;
        }
    }

    private boolean includeMember(Member m, boolean accessAll) {
        return accessAll ? (! m.isSynthetic()) : isAccessible(m);
    }

    private void prepareAccessible(AccessibleObject ao, boolean accessAll) {
        if (! accessAll) return;
        try {
            ao.setAccessible(true);
        } catch (SecurityException ignored) {}
    }

    private boolean isAccessible(Member m) {
        if (! isAccessible(m.getModifiers())) return false;

        // Where a method override has identical parameter types but a covariant (i.e
        // subclassed) return type, the JVM will not consider it to be an override. So the
        // compiler generates a synthetic "bridge" method with the original return type.
        if (m.isSynthetic()) return false;

        return true;
    }

    // Protected members need to be accessible to static proxy classes, but we can't practically do
    // that without making them accessible everywhere. Technically package members should be
    // accessible as well if the static proxy is generated in the same package, but we'll leave
    // that for now.
    private boolean isAccessible(int modifiers) {
        return (modifiers & (Modifier.PUBLIC + Modifier.PROTECTED)) != 0;
    }

}
