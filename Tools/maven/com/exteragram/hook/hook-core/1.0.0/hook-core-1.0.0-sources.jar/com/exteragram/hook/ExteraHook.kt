/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook

import com.exteragram.hook.engine.HookEngine
import com.exteragram.hook.engine.Interceptors
import com.exteragram.hook.runtime.Runtimes
import com.exteragram.hook.runtime.NativeLibrary
import java.lang.reflect.Member

object ExteraHook {
    private val backend get() = Runtimes.backend
    private val engine get() = Runtimes.engine

    @JvmStatic
    fun hook(target: Member): HookBuilder = HookBuilder(engine, HookTarget.Method(target))

    @JvmStatic
    fun hook(target: HookTarget): HookBuilder = HookBuilder(engine, target)

    @JvmStatic
    fun isHooked(target: Member): Boolean = engine.isHooked(target)

    @JvmStatic
    @Throws(Throwable::class)
    fun invokeOriginal(target: Member, thisObject: Any?, vararg args: Any?): Any? =
        engine.invokeOriginal(target, thisObject, arrayOf(*args), true)

    @JvmStatic
    fun deoptimize(target: Member): Boolean = engine.deoptimize(target)

    @JvmStatic
    val runtime: HookRuntime
        get() = backend

    @JvmStatic
    fun setLogger(logger: HookLogger?) {
        Runtimes.setLogger(logger)
    }

    @JvmStatic
    fun useEmbeddedRuntime() {
        NativeLibrary.useEmbedded()
    }

    @JvmStatic
    fun initialize(): Boolean = backend.initialize()
}

class HookBuilder internal constructor(
    private val engine: HookEngine,
    private val target: HookTarget,
) {
    private var priority = Priority.DEFAULT
    private var errorPolicy = ErrorPolicy.ISOLATE

    fun priority(value: Int): HookBuilder = apply { priority = value }

    fun errorPolicy(value: ErrorPolicy): HookBuilder = apply { errorPolicy = value }

    fun intercept(interceptor: Interceptor): HookHandle = engine.install(target, priority, errorPolicy, interceptor)

    fun before(callback: BeforeCallback): HookHandle = intercept(Interceptors.before(callback))

    fun after(callback: AfterCallback): HookHandle = intercept(Interceptors.after(callback))

    fun replace(callback: ReplaceCallback): HookHandle = intercept(Interceptors.replace(callback))
}
