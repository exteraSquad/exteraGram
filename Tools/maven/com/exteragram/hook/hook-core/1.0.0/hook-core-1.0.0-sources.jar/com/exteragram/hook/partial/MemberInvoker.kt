/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial

import java.lang.reflect.Constructor
import java.lang.reflect.Field
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Member
import java.lang.reflect.Method

internal fun interface MemberInvoker {
    @Throws(Throwable::class)
    fun invoke(receiver: Any?, args: Array<Any?>): Any?
}

internal object MemberInvokers {
    fun method(method: Method, nonvirtual: Boolean): MemberInvoker {
        method.isAccessible = true
        if (!nonvirtual) {
            return MemberInvoker { receiver, args ->
                try {
                    method.invoke(receiver, *args)
                } catch (e: InvocationTargetException) {
                    throw e.targetException
                }
            }
        }
        return nonvirtual(method, method.parameterTypes, method.returnType)
    }

    fun construct(constructor: Constructor<*>): MemberInvoker {
        constructor.isAccessible = true
        return MemberInvoker { _, args ->
            try {
                constructor.newInstance(*args)
            } catch (e: InvocationTargetException) {
                throw e.targetException
            }
        }
    }

    fun initializer(constructor: Constructor<*>): MemberInvoker =
        nonvirtual(constructor, constructor.parameterTypes, Void.TYPE)

    private fun nonvirtual(member: Member, parameterTypes: Array<Class<*>>, returnType: Class<*>): MemberInvoker {
        val shorty = buildString {
            append(shortyOf(returnType))
            parameterTypes.forEach { append(shortyOf(it)) }
        }
        return MemberInvoker { receiver, args ->
            val primitives = LongArray(args.size)
            for (i in args.indices) {
                primitives[i] = rawBits(shorty[i + 1], args[i])
            }
            val out = LongArray(1)
            val result = PartialNative.invokeNonvirtual(
                member, member.declaringClass, receiver, args, primitives, shorty, out
            )
            boxBits(shorty[0], out[0], result)
        }
    }

    fun fieldGet(field: Field): MemberInvoker {
        field.isAccessible = true
        return MemberInvoker { receiver, _ -> field.get(receiver) }
    }

    fun fieldPut(field: Field): MemberInvoker {
        field.isAccessible = true
        return MemberInvoker { receiver, args ->
            field.set(receiver, args[0])
            null
        }
    }

    private fun shortyOf(type: Class<*>): Char = when (type) {
        Void.TYPE -> 'V'
        java.lang.Boolean.TYPE -> 'Z'
        java.lang.Byte.TYPE -> 'B'
        java.lang.Character.TYPE -> 'C'
        java.lang.Short.TYPE -> 'S'
        Integer.TYPE -> 'I'
        java.lang.Long.TYPE -> 'J'
        java.lang.Float.TYPE -> 'F'
        java.lang.Double.TYPE -> 'D'
        else -> 'L'
    }

    private fun rawBits(shorty: Char, value: Any?): Long = when (shorty) {
        'Z' -> if (value as Boolean) 1L else 0L
        'B' -> (value as Byte).toLong()
        'C' -> (value as Char).code.toLong()
        'S' -> (value as Short).toLong()
        'I' -> (value as Int).toLong()
        'J' -> value as Long
        'F' -> (value as Float).toRawBits().toLong()
        'D' -> (value as Double).toRawBits()
        else -> 0L
    }

    private fun boxBits(shorty: Char, bits: Long, reference: Any?): Any? = when (shorty) {
        'V' -> null
        'Z' -> bits != 0L
        'B' -> bits.toByte()
        'C' -> bits.toInt().toChar()
        'S' -> bits.toShort()
        'I' -> bits.toInt()
        'J' -> bits
        'F' -> Float.fromBits(bits.toInt())
        'D' -> Double.fromBits(bits)
        else -> reference
    }
}
