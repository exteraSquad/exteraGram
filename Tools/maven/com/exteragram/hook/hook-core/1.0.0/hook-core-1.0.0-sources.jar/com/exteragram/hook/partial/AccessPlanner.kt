/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial

import java.lang.reflect.AccessibleObject
import java.lang.reflect.Field
import java.lang.reflect.Member
import java.lang.reflect.Modifier

internal class MemberRef(val kind: Char, val op: String, val owner: String, val name: String, val signature: String) {
    val spec: String
        get() = "$kind\t$op\t$owner\t$name\t$signature"

    override fun toString(): String = when (kind) {
        'T' -> owner
        else -> "$op $owner->$name${if (kind == 'F') ":" else ""}$signature"
    }

    companion object {
        fun parse(line: String): MemberRef {
            val parts = line.split('\t')
            return MemberRef(parts[0][0], parts[1], parts[2], parts[3], parts[4])
        }
    }
}

internal class ResolvedRef(
    val ref: MemberRef,
    val owner: Class<*>?,
    val member: AccessibleObject?,
    val accessible: Boolean,
)

internal object Descriptors {
    private val primitives = mapOf(
        'V' to Void.TYPE,
        'Z' to java.lang.Boolean.TYPE,
        'B' to java.lang.Byte.TYPE,
        'C' to java.lang.Character.TYPE,
        'S' to java.lang.Short.TYPE,
        'I' to Integer.TYPE,
        'J' to java.lang.Long.TYPE,
        'F' to java.lang.Float.TYPE,
        'D' to java.lang.Double.TYPE,
    )

    fun of(type: Class<*>): String = when {
        type.isPrimitive -> primitives.entries.first { it.value == type }.key.toString()
        type.isArray -> type.name.replace('.', '/')
        else -> "L" + type.name.replace('.', '/') + ";"
    }

    fun boxOf(type: Class<*>): Class<*> = when (type) {
        java.lang.Boolean.TYPE -> java.lang.Boolean::class.java
        java.lang.Byte.TYPE -> java.lang.Byte::class.java
        java.lang.Character.TYPE -> java.lang.Character::class.java
        java.lang.Short.TYPE -> java.lang.Short::class.java
        Integer.TYPE -> Integer::class.java
        java.lang.Long.TYPE -> java.lang.Long::class.java
        java.lang.Float.TYPE -> java.lang.Float::class.java
        java.lang.Double.TYPE -> java.lang.Double::class.java
        else -> type
    }

    fun signature(parameterTypes: Array<Class<*>>, returnType: Class<*>): String =
        parameterTypes.joinToString("", "(", ")") { of(it) } + of(returnType)

    fun classOf(descriptor: String, loader: ClassLoader?): Class<*> = when (descriptor[0]) {
        'L' -> Class.forName(descriptor.substring(1, descriptor.length - 1).replace('/', '.'), false, loader)
        '[' -> Class.forName(descriptor.replace('/', '.'), false, loader)
        else -> primitives.getValue(descriptor[0])
    }

    fun parameters(signature: String, loader: ClassLoader?): Pair<Array<Class<*>>, Class<*>> {
        val types = ArrayList<Class<*>>()
        var index = 1
        while (signature[index] != ')') {
            val start = index
            while (signature[index] == '[') {
                index++
            }
            index = if (signature[index] == 'L') signature.indexOf(';', index) + 1 else index + 1
            types.add(classOf(signature.substring(start, index), loader))
        }
        return types.toTypedArray() to classOf(signature.substring(index + 1), loader)
    }
}

internal object Reflect {
    fun field(type: Class<*>, name: String): Field {
        var current: Class<*>? = type
        while (current != null) {
            try {
                return current.getDeclaredField(name).apply { isAccessible = true }
            } catch (_: NoSuchFieldException) {
                current = current.superclass
            }
        }
        throw NoSuchFieldException("${type.name}.$name")
    }
}

internal object AccessPlanner {
    private val classFlags: Field? = try {
        Reflect.field(Class::class.java, "accessFlags")
    } catch (_: ReflectiveOperationException) {
        null
    }

    fun resolve(refs: List<MemberRef>, loader: ClassLoader?): List<ResolvedRef> = refs.map { resolve(it, loader) }

    fun isPublicClass(type: Class<*>): Boolean {
        var element = type
        while (element.isArray) {
            element = element.componentType!!
        }
        if (element.isPrimitive) {
            return true
        }
        val flags = classFlags?.getInt(element) ?: element.modifiers
        return Modifier.isPublic(flags)
    }

    private fun resolve(ref: MemberRef, loader: ClassLoader?): ResolvedRef = try {
        val owner = Descriptors.classOf(ref.owner, loader)
        when (ref.kind) {
            'T' -> ResolvedRef(ref, owner, null, isPublicClass(owner))
            'F' -> {
                val field = findField(owner, ref.name, Descriptors.classOf(ref.signature, loader))
                ResolvedRef(ref, owner, field, field == null || isAccessible(owner, field))
            }
            else -> {
                val (parameterTypes, returnType) = Descriptors.parameters(ref.signature, loader)
                val member: AccessibleObject? = if (ref.name == "<init>") {
                    owner.getDeclaredConstructor(*parameterTypes)
                } else {
                    findMethod(owner, ref.name, parameterTypes, returnType)
                }
                ResolvedRef(ref, owner, member, member == null || isAccessible(owner, member as Member))
            }
        }
    } catch (_: ReflectiveOperationException) {
        ResolvedRef(ref, null, null, true)
    } catch (_: LinkageError) {
        ResolvedRef(ref, null, null, true)
    }

    private fun isAccessible(owner: Class<*>, member: Member): Boolean =
        Modifier.isPublic(member.modifiers) && (isPublicClass(member.declaringClass) || isPublicClass(owner))

    private fun findMethod(
        owner: Class<*>,
        name: String,
        parameterTypes: Array<Class<*>>,
        returnType: Class<*>,
    ): AccessibleObject? {
        val visited = HashSet<Class<*>>()
        val interfaces = ArrayDeque<Class<*>>()
        var current: Class<*>? = owner
        while (current != null) {
            declared(current, name, parameterTypes, returnType)?.let { return it }
            interfaces.addAll(current.interfaces)
            current = current.superclass
        }
        while (interfaces.isNotEmpty()) {
            val type = interfaces.removeFirst()
            if (!visited.add(type)) {
                continue
            }
            declared(type, name, parameterTypes, returnType)?.let { return it }
            interfaces.addAll(type.interfaces)
        }
        return null
    }

    private fun declared(
        type: Class<*>,
        name: String,
        parameterTypes: Array<Class<*>>,
        returnType: Class<*>,
    ): AccessibleObject? {
        try {
            val method = type.getDeclaredMethod(name, *parameterTypes)
            if (method.returnType == returnType) {
                return method
            }
        } catch (_: NoSuchMethodException) {
            return null
        }
        return type.declaredMethods.firstOrNull {
            it.name == name && it.returnType == returnType && it.parameterTypes.contentEquals(parameterTypes)
        }
    }

    private fun findField(owner: Class<*>, name: String, type: Class<*>): Field? {
        val visited = HashSet<Class<*>>()
        fun search(current: Class<*>?): Field? {
            if (current == null || !visited.add(current)) {
                return null
            }
            current.declaredFields.firstOrNull { it.name == name && it.type == type }?.let { return it }
            for (parent in current.interfaces) {
                search(parent)?.let { return it }
            }
            return search(current.superclass)
        }
        return search(owner)
    }
}
