/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook

import java.lang.reflect.Member

interface Chain {
    val target: HookTarget
    val member: Member
    val thisObject: Any?
    @ExperimentalPartialHooks
    val caller: Any?
    val args: List<Any?>

    fun arg(index: Int): Any?

    @Throws(Throwable::class)
    fun proceed(): Any?

    @Throws(Throwable::class)
    fun proceed(args: Array<Any?>): Any?

    @Throws(Throwable::class)
    fun proceedWith(thisObject: Any?, args: Array<Any?>): Any?

    fun throwToCaller(throwable: Throwable): Nothing
}

fun interface Interceptor {
    @Throws(Throwable::class)
    fun intercept(chain: Chain): Any?
}

interface Call {
    val member: Member
    val thisObject: Any?
    val args: Array<Any?>
}

interface BeforeCall : Call {
    fun returnEarly(result: Any?)
    fun throwEarly(throwable: Throwable)
}

interface AfterCall : Call {
    val result: Any?
    val throwable: Throwable?
    fun setResult(result: Any?)
    fun setThrowable(throwable: Throwable)
}

fun interface BeforeCallback {
    @Throws(Throwable::class)
    fun before(call: BeforeCall)
}

fun interface AfterCallback {
    @Throws(Throwable::class)
    fun after(call: AfterCall)
}

fun interface ReplaceCallback {
    @Throws(Throwable::class)
    fun replace(call: Call): Any?
}
