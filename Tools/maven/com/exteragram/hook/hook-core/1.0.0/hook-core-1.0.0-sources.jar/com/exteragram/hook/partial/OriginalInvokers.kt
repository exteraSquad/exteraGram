/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial

import com.exteragram.hook.engine.OriginalAcceleration
import com.exteragram.hook.engine.OriginalAccelerator
import com.exteragram.hook.engine.OriginalCall
import com.exteragram.hook.engine.Terminal
import com.exteragram.hook.runtime.NativeLibrary
import java.lang.reflect.Constructor
import java.lang.reflect.Member
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.util.concurrent.atomic.AtomicInteger

internal object OriginalInvokers : OriginalAccelerator {
    private const val ROUTE_NONE = 0
    private const val ROUTE_TWIN = 2
    private val sequence = AtomicInteger()

    private class Holder(val id: Int, val original: Method, val twin: Method, val invoker: PartialInvoker, val keepAlive: Any)

    private val holders = HashMap<Member, Holder>()

    override fun build(target: Member, fallback: Terminal): OriginalCall? {
        val shorty = shortyOf(target) ?: return null
        NativeLibrary.ensureLoaded()
        synchronized(holders) {
            val holder = holders[target] ?: create(target, shorty).also { holders[target] = it }
            PartialDispatch.bindCall(holder.id) { _, receiver, args -> fallback.invoke(receiver, args) }
            val route = PartialNative.redirect(
                holder.original, target, holder.twin.takeIf { OriginalAcceleration.compileOriginals }
            )
            if (route == ROUTE_NONE) {
                return null
            }
            if (route == ROUTE_TWIN) {
                OriginalAcceleration.recordCompilable()
            }
            return Call(holder.invoker, fallback, holder.keepAlive)
        }
    }

    private fun create(target: Member, shorty: String): Holder {
        val id = PartialDispatch.reserveCall()
        try {
            val name = PartialEngine.GENERATED_PACKAGE + ".Original$" + sequence.incrementAndGet()
            val image = PartialNative.buildOriginal(
                "L" + name.replace('.', '/') + ";", shorty, Modifier.isStatic(target.modifiers), id
            )
            val loaded = PartialEngine.load(image, name, OriginalInvokers::class.java.classLoader, AccessStrategy.PUBLICIZE)
            val holder = loaded.load(name)
            Class.forName(name, true, holder.classLoader)
            val original = holder.declaredMethods.first { it.name == "orig" }
            val twin = holder.declaredMethods.first { it.name == "twin" }
            val invoker = loaded.load("$name\$Invoker").getDeclaredConstructor().newInstance() as PartialInvoker
            return Holder(id, original, twin, invoker, loaded.keepAlive)
        } catch (t: Throwable) {
            PartialDispatch.releaseCall(id)
            throw t
        }
    }

    private fun shortyOf(target: Member): String? {
        val (parameters, returnType) = when (target) {
            is Method -> target.parameterTypes to target.returnType
            is Constructor<*> -> target.parameterTypes to Void.TYPE
            else -> return null
        }
        return buildString {
            append(shortyOf(returnType))
            parameters.forEach { append(shortyOf(it)) }
        }
    }

    private fun shortyOf(type: Class<*>): Char = when (type) {
        java.lang.Boolean.TYPE -> 'Z'
        java.lang.Byte.TYPE -> 'B'
        java.lang.Character.TYPE -> 'C'
        java.lang.Short.TYPE -> 'S'
        java.lang.Integer.TYPE -> 'I'
        java.lang.Long.TYPE -> 'J'
        java.lang.Float.TYPE -> 'F'
        java.lang.Double.TYPE -> 'D'
        Void.TYPE -> 'V'
        else -> 'L'
    }

    private class Call(
        private val invoker: PartialInvoker,
        private val guard: Any,
        @Suppress("unused") private val keepAlive: Any,
    ) : OriginalCall {
        override fun invoke(receiver: Any?, args: Array<Any?>): Any? {
            try {
                return invoker.invoke(receiver, args)
            } finally {
                PartialDispatch.fence(guard)
            }
        }

        override fun release() {
        }
    }
}
