/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook

import java.lang.reflect.Constructor
import java.lang.reflect.Member

@RequiresOptIn(message = "Partial hooks are experimental and may change")
@Retention(AnnotationRetention.BINARY)
annotation class ExperimentalPartialHooks

sealed class HookTarget {
    abstract val member: Member

    data class Method(override val member: Member) : HookTarget()

    @ExperimentalPartialHooks
    data class CallSite(
        val inMethod: Member,
        val callee: Member,
        val occurrence: Int = ALL_OCCURRENCES,
    ) : HookTarget() {
        override val member: Member get() = callee
    }

    @ExperimentalPartialHooks
    data class FieldAccess(
        val inMethod: Member,
        val field: java.lang.reflect.Field,
        val access: Access,
        val occurrence: Int = ALL_OCCURRENCES,
    ) : HookTarget() {
        override val member: Member get() = this.field

        enum class Access {
            READ,
            WRITE,
        }
    }

    @ExperimentalPartialHooks
    data class Instruction(
        val inMethod: Member,
        val matcher: InstructionMatcher,
    ) : HookTarget() {
        override val member: Member get() = inMethod
    }

    companion object {
        const val ALL_OCCURRENCES = -1

        @JvmStatic
        @JvmOverloads
        @ExperimentalPartialHooks
        fun callSite(
            inMethod: Member,
            callee: Member,
            occurrence: Int = ALL_OCCURRENCES,
        ): HookTarget = CallSite(inMethod, callee, occurrence)

        @JvmStatic
        @JvmOverloads
        @ExperimentalPartialHooks
        fun fieldRead(
            inMethod: Member,
            field: java.lang.reflect.Field,
            occurrence: Int = ALL_OCCURRENCES,
        ): HookTarget = FieldAccess(inMethod, field, FieldAccess.Access.READ, occurrence)

        @JvmStatic
        @JvmOverloads
        @ExperimentalPartialHooks
        fun fieldWrite(
            inMethod: Member,
            field: java.lang.reflect.Field,
            occurrence: Int = ALL_OCCURRENCES,
        ): HookTarget = FieldAccess(inMethod, field, FieldAccess.Access.WRITE, occurrence)

        @JvmStatic
        @ExperimentalPartialHooks
        fun instruction(inMethod: Member, matcher: InstructionMatcher): HookTarget =
            Instruction(inMethod, matcher)
    }
}

@ExperimentalPartialHooks
sealed class InstructionMatcher {
    abstract val occurrence: Int

    data class ConstString(val text: String, override val occurrence: Int = HookTarget.ALL_OCCURRENCES) :
        InstructionMatcher()

    data class ReturnValue(override val occurrence: Int = HookTarget.ALL_OCCURRENCES) : InstructionMatcher()

    companion object {
        @JvmStatic
        @JvmOverloads
        fun constString(text: String, occurrence: Int = HookTarget.ALL_OCCURRENCES): InstructionMatcher =
            ConstString(text, occurrence)

        @JvmStatic
        @JvmOverloads
        fun returnValue(occurrence: Int = HookTarget.ALL_OCCURRENCES): InstructionMatcher = ReturnValue(occurrence)
    }
}

interface HookHandle : AutoCloseable {
    val target: HookTarget
    val priority: Int
    val isActive: Boolean

    fun unhook()

    override fun close() = unhook()
}

enum class ErrorPolicy {
    ISOLATE,
    PROPAGATE,
}

object Priority {
    const val LOWEST = -10000
    const val DEFAULT = 50
    const val HIGHEST = 10000
}

sealed class HookException(message: String, cause: Throwable? = null) : RuntimeException(message, cause) {
    class Refused(target: Member) : HookException("Hooking $target is not allowed")

    class Unsupported(target: Member, reason: String) : HookException("Cannot hook $target: $reason")

    class InstallFailed(target: Member, cause: Throwable? = null) :
        HookException("Failed to hook $target", cause)

    class Unavailable(reason: String, cause: Throwable? = null) :
        HookException("Hook runtime is unavailable: $reason", cause)
}

fun interface HookLogger {
    fun log(message: String, throwable: Throwable?)
}

interface HookRuntime {
    fun disableHiddenApiRestrictions(): Boolean
    fun disableProfileSaver(): Boolean
    fun makeClassInheritable(clazz: Class<*>): Boolean
    fun <T> allocateInstance(clazz: Class<T>): T
    fun invokeConstructor(instance: Any, constructor: Constructor<*>, vararg args: Any?): Boolean
}
