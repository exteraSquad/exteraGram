/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial

import com.exteragram.hook.runtime.NativeLibrary
import java.lang.reflect.Method

object PartialHooks {
    @JvmField
    val DEFAULT_STRATEGY = AccessStrategy.PUBLICIZE

    @JvmStatic
    @Volatile
    var accessStrategy: AccessStrategy = DEFAULT_STRATEGY

    @JvmStatic
    @Volatile
    var memoryImages: Boolean = true

    @JvmStatic
    @Volatile
    var directEntry: Boolean = true

    @JvmStatic
    @Volatile
    var publishOverridableMethods: Boolean = false

    @JvmStatic
    fun publishedCount(): Int = Publications.publishedCount()

    @JvmStatic
    fun accessFlagsOffset(field: Boolean): Int {
        NativeLibrary.ensureLoaded()
        return PartialNative.flagsOffset(field)
    }

    @JvmStatic
    fun generationOf(inMethod: Method): PartialGeneration? = PartialEngine.generationOf(inMethod)

    @JvmStatic
    fun generationCount(): Int = PartialEngine.generationCount()

    @JvmStatic
    fun entryPoint(method: Method): Long {
        NativeLibrary.ensureLoaded()
        return PartialNative.entryPoint(method)
    }

    @JvmStatic
    fun collectJitCode(): Boolean {
        NativeLibrary.ensureLoaded()
        return PartialNative.collectJitCode()
    }

    @JvmStatic
    fun accessFlags(method: Method): Long {
        NativeLibrary.ensureLoaded()
        return PartialNative.methodFlags(method)
    }
}
