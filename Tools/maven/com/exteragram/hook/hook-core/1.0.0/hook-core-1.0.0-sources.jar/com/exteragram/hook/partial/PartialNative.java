/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial;

import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

final class PartialNative {
    static final int ACC_PUBLIC = 0x0001;
    static final int ACC_SKIP_ACCESS_CHECKS = 0x00080000;

    private PartialNative() {
    }

    static native String validate(ByteBuffer dex);

    static native ByteBuffer memoryImage(long dexFile);

    static native boolean containsClass(ByteBuffer dex, String descriptor);

    static native String[] scan(ByteBuffer dex, String owner, String name, String signature);

    static native byte[] patch(ByteBuffer dex, String owner, String name, String signature, String generatedClass,
                               String[] sites, String[] accessors, String[] siteInfo);

    static native boolean addMethodFlags(Member executable, int flags, int modifiers);

    static native boolean addFieldFlags(Field field, int flags, int modifiers);

    static native boolean addClassFlags(Class<?> target, int flags);

    static native boolean removeMethodFlags(Member executable, int flags, int modifiers);

    static native boolean removeFieldFlags(Field field, int flags, int modifiers);

    static native boolean removeClassFlags(Class<?> target, int flags);

    static native int flagsOffset(boolean field);

    static native boolean retarget(Member target, Method body);

    static native byte[] buildOriginal(String generatedClass, String shorty, boolean isStatic, int id);

    static native int redirect(Method from, Member target, Method twin);

    static native boolean collectJitCode();

    static native long methodFlags(Member executable);

    static native long entryPoint(Member executable);

    static native Object invokeNonvirtual(Member method, Class<?> declaring, Object receiver, Object[] references,
                                          long[] primitives, String shorty, long[] out);
}
