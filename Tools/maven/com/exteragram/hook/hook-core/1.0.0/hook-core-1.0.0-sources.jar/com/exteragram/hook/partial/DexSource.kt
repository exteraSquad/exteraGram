/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial

import dalvik.system.BaseDexClassLoader
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.lang.ref.SoftReference
import java.nio.ByteBuffer
import java.util.WeakHashMap
import java.util.zip.ZipFile

internal class DexImage(val buffer: ByteBuffer, val origin: String)

internal object DexSource {
    private val entryName = Regex("classes\\d*\\.dex")
    private val cache = HashMap<String, SoftReference<ByteBuffer>>()
    private val memory = WeakHashMap<ClassLoader, HashMap<Long, DexImage?>>()

    fun locate(clazz: Class<*>): DexImage {
        val descriptor = Descriptors.of(clazz)
        val loader = clazz.classLoader
        val dexFile = dexFileOf(clazz)
        if (loader != null && dexFile != 0L) {
            if (PartialHooks.memoryImages) {
                fromMemory(loader, dexFile, descriptor)?.let { return it }
            }
            fromCookie(loader, dexFile, descriptor)?.let { return it }
        }
        fromClassDex(clazz)?.let { return it }
        loader ?: throw UnsupportedOperationException("boot classpath classes are not supported: ${clazz.name}")
        val paths = dexElements(loader).mapNotNull { pathOf(it) }.distinct()
        for (path in paths) {
            fromPath(path, descriptor)?.let { return it }
        }
        throw UnsupportedOperationException("no dex source for ${clazz.name} in $paths")
    }

    private fun dexFileOf(clazz: Class<*>): Long = try {
        val dexCache = Reflect.field(Class::class.java, "dexCache").get(clazz)
        if (dexCache == null) 0L else Reflect.field(dexCache.javaClass, "dexFile").getLong(dexCache)
    } catch (_: ReflectiveOperationException) {
        0L
    }

    private fun fromMemory(loader: ClassLoader, dexFile: Long, descriptor: String): DexImage? {
        val image = synchronized(memory) {
            val images = memory.getOrPut(loader) { HashMap() }
            if (images.containsKey(dexFile)) {
                images[dexFile]
            } else {
                val buffer = PartialNative.memoryImage(dexFile)
                val image = if (buffer != null && PartialNative.validate(buffer) == null) {
                    DexImage(buffer, "memory@0x" + java.lang.Long.toHexString(dexFile))
                } else {
                    null
                }
                images[dexFile] = image
                image
            }
        }
        return image?.takeIf { PartialNative.containsClass(it.buffer, descriptor) }
    }

    private fun fromCookie(loader: ClassLoader, dexFile: Long, descriptor: String): DexImage? = try {
        cookieImage(loader, dexFile, descriptor)
    } catch (_: IOException) {
        null
    }

    private fun cookieImage(loader: ClassLoader, dexFile: Long, descriptor: String): DexImage? {
        for (element in dexElements(loader)) {
            val file = try {
                Reflect.field(element.javaClass, "dexFile").get(element)
            } catch (_: ReflectiveOperationException) {
                null
            } ?: continue
            val cookie = try {
                Reflect.field(file.javaClass, "mCookie").get(file) as? LongArray
            } catch (_: ReflectiveOperationException) {
                null
            } ?: continue
            val index = (1 until cookie.size).firstOrNull { cookie[it] == dexFile } ?: continue
            val path = pathOf(element) ?: return null
            val image = if (path.endsWith(".dex")) {
                fromDexFile(path)
            } else {
                val entry = if (index == 1) "classes.dex" else "classes$index.dex"
                ZipFile(path).use { zip ->
                    val zipEntry = zip.getEntry(entry) ?: return null
                    val key = "$path!$entry"
                    DexImage(cached(key) { zip.getInputStream(zipEntry).use { read(it, zipEntry.size.toInt()) } }, key)
                }
            }
            return image.takeIf { PartialNative.containsClass(it.buffer, descriptor) }
        }
        return null
    }

    private fun fromClassDex(clazz: Class<*>): DexImage? = try {
        val dex = Class::class.java.getDeclaredMethod("getDex").invoke(clazz)
        val bytes = dex.javaClass.getMethod("getBytes").invoke(dex) as ByteArray
        direct(bytes).also { verify(it, "Class.getDex") }.let { DexImage(it, "Class.getDex") }
    } catch (_: ReflectiveOperationException) {
        null
    }

    private fun dexElements(loader: ClassLoader): List<Any> {
        if (loader !is BaseDexClassLoader) {
            return emptyList()
        }
        return try {
            val pathList = Reflect.field(BaseDexClassLoader::class.java, "pathList").get(loader) ?: return emptyList()
            (Reflect.field(pathList.javaClass, "dexElements").get(pathList) as Array<*>).filterNotNull()
        } catch (_: ReflectiveOperationException) {
            emptyList()
        }
    }

    private fun pathOf(element: Any): String? = try {
        val dexFile = Reflect.field(element.javaClass, "dexFile").get(element)
        val name = dexFile?.javaClass?.getMethod("getName")?.invoke(dexFile) as? String
        name?.takeIf { File(it).isFile }
    } catch (_: ReflectiveOperationException) {
        null
    }

    private fun fromDexFile(path: String): DexImage =
        DexImage(cached(path) { File(path).inputStream().use { read(it, File(path).length().toInt()) } }, path)

    private fun fromPath(path: String, descriptor: String): DexImage? {
        if (path.endsWith(".dex")) {
            return fromDexFile(path).takeIf { PartialNative.containsClass(it.buffer, descriptor) }
        }
        ZipFile(path).use { zip ->
            val entries = zip.entries().asSequence().filter { entryName.matches(it.name) }.sortedBy { it.name }
            for (entry in entries) {
                val key = "$path!${entry.name}"
                val buffer = cached(key) { zip.getInputStream(entry).use { read(it, entry.size.toInt()) } }
                if (PartialNative.containsClass(buffer, descriptor)) {
                    return DexImage(buffer, key)
                }
            }
        }
        return null
    }

    private fun cached(key: String, load: () -> ByteBuffer): ByteBuffer = synchronized(cache) {
        cache[key]?.get() ?: load().also { verify(it, key); cache[key] = SoftReference(it) }
    }

    private fun verify(buffer: ByteBuffer, origin: String) {
        PartialNative.validate(buffer)?.let { throw UnsupportedOperationException("damaged dex image $origin: $it") }
    }

    private fun read(stream: InputStream, size: Int): ByteBuffer {
        if (size < 0) {
            return direct(stream.readBytes())
        }
        val bytes = ByteArray(size)
        var offset = 0
        while (offset < size) {
            val count = stream.read(bytes, offset, size - offset)
            if (count < 0) {
                throw EOFException("dex image is shorter than $size bytes")
            }
            offset += count
        }
        return direct(bytes)
    }

    private fun direct(bytes: ByteArray): ByteBuffer {
        val buffer = ByteBuffer.allocateDirect(bytes.size)
        buffer.put(bytes)
        buffer.flip()
        return buffer
    }
}
