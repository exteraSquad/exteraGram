/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.runtime;

import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;

public final class NativeBindings {
    public static final int TARGET_ALLOWED = 0;
    public static final int TARGET_REFUSED = 1;
    public static final int TARGET_UNAVAILABLE = 2;

    private NativeBindings() {
    }

    static native boolean initialize0();

    static native int checkTarget0(Member target);

    static native Method hook0(Object context, Member target, Method callback);

    static native boolean unhook0(Member target);

    static native boolean isHooked0(Member target);

    static native boolean deoptimize0(Member target);

    static native boolean makeClassInheritable0(Class<?> target);

    static native Object allocateInstance0(Class<?> type);

    static native boolean invokeConstructor0(Object instance, Constructor<?> constructor, Object[] args);

    static native boolean disableProfileSaver0();

    static native boolean disableHiddenApiRestrictions0();
}
