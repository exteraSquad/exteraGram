/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.runtime

import android.os.Build
import android.util.Log
import com.exteragram.hook.HookException
import com.exteragram.hook.HookLogger
import com.exteragram.hook.HookRuntime
import com.exteragram.hook.engine.HookBackend
import com.exteragram.hook.engine.HookEngine
import com.exteragram.hook.engine.TargetVerdict
import com.exteragram.hook.engine.Trampoline
import com.exteragram.hook.partial.OriginalInvokers
import com.exteragram.hook.partial.PartialEngine
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.io.File
import java.lang.reflect.Constructor
import java.lang.reflect.Member
import java.lang.reflect.Method

object NativeLibrary {
    private const val LIBRARY = "exterahook"

    @Volatile
    private var embedded = false

    @Volatile
    private var loaded = false

    fun useEmbedded() {
        embedded = true
    }

    @Synchronized
    fun ensureLoaded() {
        if (loaded) {
            return
        }
        HiddenApi.disableWithJava()
        if (!embedded) {
            try {
                System.loadLibrary(LIBRARY)
            } catch (t: Throwable) {
                throw HookException.Unavailable("cannot load lib$LIBRARY.so", t)
            }
        }
        loaded = true
        dropRuntimeImage()
    }

    private fun dropRuntimeImage() {
        if (Build.VERSION.SDK_INT < 34) {
            return
        }
        try {
            val cache = System.getProperty("java.io.tmpdir") ?: return
            File(cache, "oat_primary").takeIf { it.isDirectory }?.deleteRecursively()
        } catch (_: Throwable) {
        }
    }
}

internal object HiddenApi {
    @Volatile
    private var disabled = false

    fun disableWithJava(): Boolean = try {
        HiddenApiBypass.addHiddenApiExemptions("")
    } catch (_: Throwable) {
        false
    }

    @Synchronized
    fun disable(): Boolean {
        if (disabled) {
            return true
        }
        disabled = disableWithJava() || NativeBindings.disableHiddenApiRestrictions0()
        return disabled
    }
}

object Runtimes {
    @Volatile
    private var currentLogger: HookLogger = AndroidLogger

    @JvmStatic
    val backend: JniHookBackend by lazy { JniHookBackend() }

    @JvmStatic
    val engine: HookEngine by lazy {
        HookEngine(backend) { currentLogger }.also {
            it.partial = PartialEngine
            it.accelerator = OriginalInvokers
        }
    }

    @JvmStatic
    fun setLogger(logger: HookLogger?) {
        currentLogger = logger ?: AndroidLogger
    }

    @JvmStatic
    fun log(message: String, throwable: Throwable?) {
        try {
            currentLogger.log(message, throwable)
        } catch (_: Throwable) {
        }
    }
}

object AndroidLogger : HookLogger {
    override fun log(message: String, throwable: Throwable?) {
        Log.e("exteraHook", message, throwable)
    }
}

class JniHookBackend : HookBackend, HookRuntime {
    fun initialize(): Boolean {
        NativeLibrary.ensureLoaded()
        return NativeBindings.initialize0()
    }

    override fun check(target: Member): TargetVerdict {
        NativeLibrary.ensureLoaded()
        return when (NativeBindings.checkTarget0(target)) {
            NativeBindings.TARGET_ALLOWED -> TargetVerdict.ALLOWED
            NativeBindings.TARGET_REFUSED -> TargetVerdict.REFUSED
            else -> TargetVerdict.UNAVAILABLE
        }
    }

    override fun install(trampoline: Trampoline, target: Member): Method? =
        NativeBindings.hook0(trampoline, target, Trampoline.CALLBACK)

    override fun uninstall(target: Member): Boolean = NativeBindings.unhook0(target)

    override fun deoptimize(target: Member): Boolean {
        NativeLibrary.ensureLoaded()
        return NativeBindings.deoptimize0(target)
    }

    override fun disableHiddenApiRestrictions(): Boolean {
        NativeLibrary.ensureLoaded()
        return HiddenApi.disable()
    }

    override fun disableProfileSaver(): Boolean {
        NativeLibrary.ensureLoaded()
        return NativeBindings.disableProfileSaver0()
    }

    override fun makeClassInheritable(clazz: Class<*>): Boolean {
        NativeLibrary.ensureLoaded()
        return NativeBindings.makeClassInheritable0(clazz)
    }

    override fun <T> allocateInstance(clazz: Class<T>): T {
        NativeLibrary.ensureLoaded()
        @Suppress("UNCHECKED_CAST")
        return NativeBindings.allocateInstance0(clazz) as T
            ?: throw HookException.Unavailable("cannot allocate ${clazz.name}")
    }

    override fun invokeConstructor(instance: Any, constructor: Constructor<*>, vararg args: Any?): Boolean {
        require(!constructor.isVarArgs) { "varargs parameters are not supported" }
        NativeLibrary.ensureLoaded()
        return NativeBindings.invokeConstructor0(instance, constructor, if (args.isEmpty()) null else arrayOf(*args))
    }
}
