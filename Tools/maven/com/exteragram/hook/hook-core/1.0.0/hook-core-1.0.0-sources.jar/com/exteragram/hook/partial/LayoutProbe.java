/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial;

final class LayoutProbe {
    public static final int publicStaticFinal = 1;
    private volatile Object privateVolatile;
    protected final long protectedFinal = 2;
    static int packageStatic;
    private static Object privateStatic;
    public transient int publicTransient;
    protected Object protectedPlain;
    int packagePlain;

    private LayoutProbe() {
    }

    public static void publicStatic() {
    }

    private void privatePlain() {
    }

    protected final void protectedFinal() {
    }

    static void packageStatic() {
    }

    private static void privateStatic() {
    }

    public void publicPlain() {
    }

    protected void protectedPlain() {
    }

    void packagePlain() {
    }
}
