/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.engine

import com.exteragram.hook.ErrorPolicy
import com.exteragram.hook.ExperimentalPartialHooks
import com.exteragram.hook.HookTarget
import com.exteragram.hook.InstructionMatcher
import com.exteragram.hook.Interceptor
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Member
import java.lang.reflect.Method
import java.lang.reflect.Modifier

internal class Entry(
    val interceptor: Interceptor,
    val priority: Int,
    val sequence: Long,
    val policy: ErrorPolicy,
)

fun interface Terminal {
    @Throws(Throwable::class)
    fun invoke(thisObject: Any?, args: Array<Any?>): Any?
}

internal fun interface DirectEntry {
    fun switch(enabled: Boolean): Boolean
}

internal class HookRecord(
    val target: HookTarget,
    private val engine: HookEngine,
) {
    val member: Member = target.member
    val isStatic: Boolean = Modifier.isStatic(member.modifiers)

    @OptIn(ExperimentalPartialHooks::class)
    private val returnType: Class<*>? = when (target) {
        is HookTarget.FieldAccess -> target.field.type.takeIf { target.access == HookTarget.FieldAccess.Access.READ }
        is HookTarget.Instruction -> when (target.matcher) {
            is InstructionMatcher.ConstString -> String::class.java
            is InstructionMatcher.ReturnValue -> (target.inMethod as? Method)?.returnType
        }
        is HookTarget.CallSite -> (member as? Method)?.returnType ?: member.declaringClass
        else -> (member as? Method)?.returnType
    }?.takeIf { it != Void.TYPE }
    private val boxedReturnType: Class<*>? = returnType?.let(::box)

    @Volatile
    var entries: Array<Entry> = EMPTY
        private set

    @Volatile
    var terminal: Terminal? = null

    var direct: DirectEntry? = null

    var activeDirect: DirectEntry? = null

    private val backupLock = Object()

    @Volatile
    private var backup: Method? = null

    @Volatile
    private var installFailed = false

    @Volatile
    private var installingThread: Thread? = Thread.currentThread()

    @Volatile
    private var fastOriginal: OriginalCall? = null

    @Volatile
    private var originalCalls = 0

    private val accelerationState = java.util.concurrent.atomic.AtomicInteger(ACCELERATION_IDLE)

    private val parameterTypes: Array<Class<*>> = when (member) {
        is Method -> member.parameterTypes
        is java.lang.reflect.Constructor<*> -> member.parameterTypes
        else -> emptyArray()
    }

    private val parameterBoxes: Array<Class<*>?> = Array(parameterTypes.size) { box(parameterTypes[it]) }

    fun add(entry: Entry) {
        entries = (entries + entry).sortedWith(ORDER).toTypedArray()
    }

    fun remove(entry: Entry): Boolean {
        val current = entries
        if (entry !in current) {
            return false
        }
        entries = current.filter { it !== entry }.toTypedArray()
        return true
    }

    fun publishBackup(method: Method) {
        if (!method.isAccessible) {
            method.isAccessible = true
        }
        synchronized(backupLock) {
            backup = method
            installingThread = null
            backupLock.notifyAll()
        }
    }

    fun markInstallFailed() {
        synchronized(backupLock) {
            if (backup != null) {
                return
            }
            installFailed = true
            installingThread = null
            backupLock.notifyAll()
        }
    }

    fun dispatch(rawArgs: Array<Any?>): Any? {
        val thisObject = if (isStatic) null else rawArgs[0]
        val args = if (isStatic) rawArgs else rawArgs.copyOfRange(1, rawArgs.size)
        return run(thisObject, args)
    }

    fun run(thisObject: Any?, args: Array<Any?>, caller: Any? = null): Any? {
        val snapshot = entries
        if (snapshot.isEmpty()) {
            return proceedTerminal(thisObject, args)
        }
        return ChainImpl(this, snapshot, 0, thisObject, args, caller).run()
    }

    fun proceedTerminal(thisObject: Any?, args: Array<Any?>): Any? {
        val current = terminal ?: return invokeOriginal(thisObject, args)
        return current.invoke(thisObject, args)
    }

    fun invokeOriginal(thisObject: Any?, args: Array<Any?>): Any? {
        val fast = fastOriginal
        if (fast != null) {
            if (accepts(thisObject, args)) {
                return fast.invoke(thisObject, args)
            }
        } else if (accelerationState.get() == ACCELERATION_IDLE && ++originalCalls >= OriginalAcceleration.threshold) {
            accelerate()
        }
        return invokeReflectively(thisObject, args)
    }

    fun releaseAcceleration() {
        accelerationState.set(ACCELERATION_DONE)
        fastOriginal?.let {
            fastOriginal = null
            it.release()
        }
    }

    private fun accelerate() {
        if (!OriginalAcceleration.enabled || backup == null || java.lang.reflect.Proxy.isProxyClass(member.declaringClass)) {
            return
        }
        val accelerator = engine.accelerator ?: return
        if (!accelerationState.compareAndSet(ACCELERATION_IDLE, ACCELERATION_BUILDING)) {
            return
        }
        try {
            OriginalAcceleration.executor.execute { build(accelerator) }
        } catch (t: Throwable) {
            accelerationState.set(ACCELERATION_DONE)
            engine.reportFailure("Cannot schedule a direct original call for $member", t)
        }
    }

    private fun build(accelerator: OriginalAccelerator) {
        val built = try {
            accelerator.build(member) { receiver, args -> invokeReflectively(receiver, args) }
        } catch (t: Throwable) {
            engine.reportFailure("Cannot build a direct original call for $member", t)
            null
        }
        if (built != null && accelerationState.compareAndSet(ACCELERATION_BUILDING, ACCELERATION_DONE)) {
            fastOriginal = built
            OriginalAcceleration.recordBuilt()
            if (!engine.isInstalled(this)) {
                releaseAcceleration()
            }
            return
        }
        accelerationState.set(ACCELERATION_DONE)
        built?.release()
    }

    private fun accepts(thisObject: Any?, args: Array<Any?>): Boolean {
        val types = parameterTypes
        if (args.size != types.size) {
            return false
        }
        if (!isStatic && !member.declaringClass.isInstance(thisObject)) {
            return false
        }
        for (i in types.indices) {
            val arg = args[i]
            val boxed = parameterBoxes[i]
            if (boxed != null) {
                if (arg == null || arg.javaClass !== boxed) {
                    return false
                }
            } else if (arg != null && !types[i].isInstance(arg)) {
                return false
            }
        }
        return true
    }

    private fun invokeReflectively(thisObject: Any?, args: Array<Any?>): Any? {
        try {
            return awaitBackup().invoke(thisObject, *args)
        } catch (e: InvocationTargetException) {
            throw e.cause ?: e
        }
    }

    fun invokeOriginalReflectively(thisObject: Any?, args: Array<Any?>): Any? = awaitBackup().invoke(thisObject, *args)

    fun checkResult(value: Any?): Any? {
        if (returnType == null) {
            return null
        }
        val expected = boxedReturnType ?: returnType
        if (value == null && boxedReturnType == null) {
            return null
        }
        if (!expected.isInstance(value)) {
            throw IllegalStateException(
                "Interceptor returned ${value?.javaClass?.name ?: "null"} for $member; expected ${expected.name}"
            )
        }
        return value
    }

    fun reportInterceptorFailure(entry: Entry, throwable: Throwable) {
        engine.reportFailure("Interceptor with priority ${entry.priority} on $member failed", throwable)
    }

    private fun awaitBackup(): Method = backup ?: awaitBackupSlowPath()

    private fun awaitBackupSlowPath(): Method {
        var interrupted = false
        try {
            synchronized(backupLock) {
                check(Thread.currentThread() !== installingThread) {
                    "The original of $member is not published yet, the hook is still being installed on this thread"
                }
                val deadline = System.nanoTime() + BACKUP_TIMEOUT_MS * 1_000_000L
                var remaining = BACKUP_TIMEOUT_MS
                while (backup == null && !installFailed && remaining > 0) {
                    try {
                        backupLock.wait(remaining)
                    } catch (_: InterruptedException) {
                        interrupted = true
                    }
                    remaining = (deadline - System.nanoTime()) / 1_000_000L
                }
                backup?.let { return it }
            }
        } finally {
            if (interrupted) {
                Thread.currentThread().interrupt()
            }
        }
        check(!installFailed) { "Hooking $member failed, the original is unavailable" }
        throw IllegalStateException("The original of $member was not published within ${BACKUP_TIMEOUT_MS}ms")
    }

    companion object {
        private const val BACKUP_TIMEOUT_MS = 1000L
        private const val ACCELERATION_IDLE = 0
        private const val ACCELERATION_BUILDING = 1
        private const val ACCELERATION_DONE = 2
        private val EMPTY = emptyArray<Entry>()
        private val ORDER = compareByDescending<Entry> { it.priority }.thenBy { it.sequence }

        private fun box(type: Class<*>): Class<*>? = when (type) {
            java.lang.Boolean.TYPE -> java.lang.Boolean::class.java
            java.lang.Byte.TYPE -> java.lang.Byte::class.java
            java.lang.Character.TYPE -> java.lang.Character::class.java
            java.lang.Short.TYPE -> java.lang.Short::class.java
            java.lang.Integer.TYPE -> java.lang.Integer::class.java
            java.lang.Long.TYPE -> java.lang.Long::class.java
            java.lang.Float.TYPE -> java.lang.Float::class.java
            java.lang.Double.TYPE -> java.lang.Double::class.java
            else -> null
        }
    }
}
