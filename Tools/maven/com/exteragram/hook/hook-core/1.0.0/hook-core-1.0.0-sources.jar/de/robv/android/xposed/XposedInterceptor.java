/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package de.robv.android.xposed;

import com.exteragram.hook.Chain;
import com.exteragram.hook.Interceptor;

import java.lang.reflect.Member;
import java.lang.reflect.Method;

final class XposedInterceptor implements Interceptor {
    private final XC_MethodHook callback;
    private final Class<?> boxedPrimitiveReturnType;

    XposedInterceptor(XC_MethodHook callback, Member member) {
        this.callback = callback;
        this.boxedPrimitiveReturnType = boxedPrimitiveReturnType(member);
    }

    @Override
    public Object intercept(Chain chain) throws Throwable {
        var param = new XC_MethodHook.MethodHookParam();
        param.method = chain.getMember();
        param.thisObject = chain.getThisObject();
        param.args = chain.getArgs().toArray();

        try {
            callback.beforeHookedMethod(param);
            if (param.returnEarly) {
                ensureValidPrimitiveResult(param);
            }
        } catch (Throwable t) {
            XposedBridge.log(t);
            param.setResult(null);
            param.returnEarly = false;
        }

        Throwable fromChain = null;
        if (!param.returnEarly) {
            try {
                param.setResult(chain.proceedWith(param.thisObject, param.args));
            } catch (Throwable t) {
                fromChain = t;
                param.setThrowable(t);
            }
        }

        var lastResult = param.getResult();
        var lastThrowable = param.getThrowable();
        try {
            callback.afterHookedMethod(param);
            ensureValidPrimitiveResult(param);
        } catch (Throwable t) {
            XposedBridge.log(t);
            if (lastThrowable == null) {
                param.setResult(lastResult);
            } else {
                param.setThrowable(lastThrowable);
            }
        }

        var throwable = param.getThrowable();
        if (throwable == null) {
            return param.getResult();
        }
        if (throwable == fromChain) {
            throw throwable;
        }
        chain.throwToCaller(throwable);
        return null;
    }

    private void ensureValidPrimitiveResult(XC_MethodHook.MethodHookParam param) {
        var result = param.getResult();
        if (boxedPrimitiveReturnType != null && !param.hasThrowable() && !boxedPrimitiveReturnType.isInstance(result)) {
            throw new IllegalStateException("Hook returned " + (result == null ? "null" : result.getClass().getName())
                    + " for primitive method " + param.method + "; expected " + boxedPrimitiveReturnType.getName());
        }
    }

    private static Class<?> boxedPrimitiveReturnType(Member member) {
        if (!(member instanceof Method)) {
            return null;
        }
        var type = ((Method) member).getReturnType();
        if (type == boolean.class) return Boolean.class;
        if (type == byte.class) return Byte.class;
        if (type == char.class) return Character.class;
        if (type == short.class) return Short.class;
        if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class;
        if (type == float.class) return Float.class;
        if (type == double.class) return Double.class;
        return null;
    }
}
