/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.engine

import java.lang.reflect.Member
import java.lang.reflect.Method

enum class TargetVerdict {
    ALLOWED,
    REFUSED,
    UNAVAILABLE,
}

interface HookBackend {
    fun check(target: Member): TargetVerdict

    fun install(trampoline: Trampoline, target: Member): Method?

    fun uninstall(target: Member): Boolean

    fun deoptimize(target: Member): Boolean
}
