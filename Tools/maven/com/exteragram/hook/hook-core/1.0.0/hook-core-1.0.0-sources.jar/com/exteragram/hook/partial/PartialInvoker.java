/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial;

public interface PartialInvoker {
    Object invoke(Object receiver, Object[] args) throws Throwable;
}
