/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.engine

import java.lang.reflect.Method

class Trampoline internal constructor(private val record: HookRecord) {
    @Throws(Throwable::class)
    fun callback(args: Array<Any?>): Any? = record.dispatch(args)

    companion object {
        @JvmField
        val CALLBACK: Method = Trampoline::class.java.getMethod("callback", Array<Any?>::class.java)
    }
}
