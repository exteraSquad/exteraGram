/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.engine

import java.lang.reflect.Member
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

interface OriginalCall {
    @Throws(Throwable::class)
    fun invoke(receiver: Any?, args: Array<Any?>): Any?

    fun release()
}

fun interface OriginalAccelerator {
    fun build(target: Member, fallback: Terminal): OriginalCall?
}

object OriginalAcceleration {
    @JvmStatic
    @Volatile
    var enabled: Boolean = true

    @JvmStatic
    @Volatile
    var threshold: Int = 4096

    @JvmStatic
    @Volatile
    var executor: Executor = Executor { task -> background.execute(task) }

    @JvmStatic
    @Volatile
    var compileOriginals: Boolean = true

    private val built = AtomicInteger()

    private val compilable = AtomicInteger()

    @JvmStatic
    fun builtCount(): Int = built.get()

    @JvmStatic
    fun compilableCount(): Int = compilable.get()

    internal fun recordBuilt() {
        built.incrementAndGet()
    }

    internal fun recordCompilable() {
        compilable.incrementAndGet()
    }

    private val background by lazy {
        Executors.newSingleThreadExecutor { task ->
            Thread(task, "exteraHook-original").apply { isDaemon = true }
        }
    }
}
