/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.engine

import com.exteragram.hook.AfterCall
import com.exteragram.hook.AfterCallback
import com.exteragram.hook.BeforeCall
import com.exteragram.hook.BeforeCallback
import com.exteragram.hook.Call
import com.exteragram.hook.Chain
import com.exteragram.hook.Interceptor
import com.exteragram.hook.ReplaceCallback
import java.lang.reflect.Member

internal object Interceptors {
    fun before(callback: BeforeCallback) = Interceptor { chain ->
        val call = BeforeCallImpl(chain)
        callback.before(call)
        call.earlyThrowable?.let { chain.throwToCaller(it) }
        if (call.returnedEarly) call.earlyResult else chain.proceedWith(call.thisObject, call.args)
    }

    fun after(callback: AfterCallback) = Interceptor { chain ->
        val call = try {
            AfterCallImpl(chain, chain.proceed(), null)
        } catch (t: Throwable) {
            AfterCallImpl(chain, null, t)
        }
        callback.after(call)
        call.throwable?.let { if (it === call.originalThrowable) throw it else chain.throwToCaller(it) }
        call.result
    }

    fun replace(callback: ReplaceCallback) = Interceptor { chain -> callback.replace(CallImpl(chain)) }

    private open class CallImpl(chain: Chain) : Call {
        override val member: Member = chain.member
        override val thisObject: Any? = chain.thisObject
        override val args: Array<Any?> = chain.args.toTypedArray()
    }

    private class BeforeCallImpl(chain: Chain) : CallImpl(chain), BeforeCall {
        var returnedEarly = false
        var earlyResult: Any? = null
        var earlyThrowable: Throwable? = null

        override fun returnEarly(result: Any?) {
            returnedEarly = true
            earlyResult = result
            earlyThrowable = null
        }

        override fun throwEarly(throwable: Throwable) {
            returnedEarly = true
            earlyResult = null
            earlyThrowable = throwable
        }
    }

    private class AfterCallImpl(chain: Chain, result: Any?, val originalThrowable: Throwable?) : CallImpl(chain), AfterCall {
        private var currentResult: Any? = result
        private var currentThrowable: Throwable? = originalThrowable

        override val result: Any? get() = currentResult

        override val throwable: Throwable? get() = currentThrowable

        override fun setResult(result: Any?) {
            currentResult = result
            currentThrowable = null
        }

        override fun setThrowable(throwable: Throwable) {
            currentResult = null
            currentThrowable = throwable
        }
    }
}
