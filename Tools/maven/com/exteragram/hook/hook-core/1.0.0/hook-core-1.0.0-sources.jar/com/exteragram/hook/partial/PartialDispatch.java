/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial;

import java.util.ArrayDeque;
import java.util.Arrays;

public final class PartialDispatch {
    interface Target {
        Object dispatch(Object receiver, Object[] args) throws Throwable;
    }

    interface CallTarget {
        Object dispatch(Object caller, Object receiver, Object[] args) throws Throwable;
    }

    private static final Object lock = new Object();
    private static volatile CallTarget[] calls = new CallTarget[0];
    private static volatile Target[] accessors = new Target[0];
    private static final ArrayDeque<Integer> freeCalls = new ArrayDeque<>();

    private PartialDispatch() {
    }

    public static Object call(int id, Object caller, Object receiver, Object[] args) throws Throwable {
        return calls[id].dispatch(caller, receiver, args);
    }

    public static Object access(int id, Object receiver, Object[] args) throws Throwable {
        return accessors[id].dispatch(receiver, args);
    }

    private static volatile Object fenced;

    static void fence(Object guard) {
        if (guard == fenced) {
            fenced = null;
        }
    }

    static int reserveCall() {
        synchronized (lock) {
            Integer free = freeCalls.poll();
            if (free != null) {
                return free;
            }
            calls = Arrays.copyOf(calls, calls.length + 1);
            return calls.length - 1;
        }
    }

    static void bindCall(int id, CallTarget target) {
        synchronized (lock) {
            CallTarget[] copy = calls.clone();
            copy[id] = target;
            calls = copy;
        }
    }

    static void releaseCall(int id) {
        synchronized (lock) {
            CallTarget[] copy = calls.clone();
            copy[id] = null;
            calls = copy;
            freeCalls.add(id);
        }
    }

    static int reserveAccessor() {
        synchronized (lock) {
            accessors = Arrays.copyOf(accessors, accessors.length + 1);
            return accessors.length - 1;
        }
    }

    static void bindAccessor(int id, Target target) {
        synchronized (lock) {
            Target[] copy = accessors.clone();
            copy[id] = target;
            accessors = copy;
        }
    }
}
