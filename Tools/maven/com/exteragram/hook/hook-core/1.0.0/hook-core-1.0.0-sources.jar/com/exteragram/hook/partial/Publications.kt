/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial

import java.lang.ref.PhantomReference
import java.lang.ref.ReferenceQueue
import java.lang.reflect.Field
import java.lang.reflect.Member
import java.lang.reflect.Modifier

internal object Publications {
    private class Lease(referent: Any, queue: ReferenceQueue<Any>, val keys: List<Any>) :
        PhantomReference<Any>(referent, queue)

    private val lock = Any()
    private val counts = HashMap<Any, Int>()
    private val leases = HashSet<Lease>()
    private val queue = ReferenceQueue<Any>()
    private var reaper: Thread? = null

    fun acquire(key: Any, into: MutableList<Any>) {
        synchronized(lock) {
            val count = counts[key]
            if (count != null) {
                counts[key] = count + 1
                into.add(key)
                return
            }
            if (isPublic(key)) {
                return
            }
            check(add(key)) { "cannot publicize $key" }
            counts[key] = 1
            into.add(key)
        }
    }

    fun release(keys: List<Any>) {
        synchronized(lock) {
            for (key in keys) {
                val count = counts[key] ?: continue
                if (count > 1) {
                    counts[key] = count - 1
                    continue
                }
                counts.remove(key)
                remove(key)
            }
        }
    }

    fun bind(keys: List<Any>, owner: Any) {
        if (keys.isEmpty()) {
            return
        }
        synchronized(lock) {
            leases.add(Lease(owner, queue, ArrayList(keys)))
            if (reaper == null) {
                reaper = Thread(::reap, "exteraHook-publications").apply {
                    isDaemon = true
                    start()
                }
            }
        }
    }

    fun publishedCount(): Int = synchronized(lock) { counts.size }

    private fun reap() {
        while (true) {
            val lease = try {
                queue.remove() as Lease
            } catch (_: InterruptedException) {
                continue
            }
            synchronized(lock) {
                leases.remove(lease)
            }
            try {
                release(lease.keys)
            } catch (_: Throwable) {
            }
        }
    }

    private fun isPublic(key: Any): Boolean = when (key) {
        is Class<*> -> AccessPlanner.isPublicClass(key)
        is Member -> Modifier.isPublic(key.modifiers)
        else -> true
    }

    private fun add(key: Any): Boolean = when (key) {
        is Class<*> -> PartialNative.addClassFlags(key, PartialNative.ACC_PUBLIC)
        is Field -> PartialNative.addFieldFlags(key, PartialNative.ACC_PUBLIC, key.modifiers)
        is Member -> PartialNative.addMethodFlags(key, PartialNative.ACC_PUBLIC, key.modifiers)
        else -> false
    }

    private fun remove(key: Any) {
        when (key) {
            is Class<*> -> PartialNative.removeClassFlags(key, PartialNative.ACC_PUBLIC)
            is Field -> PartialNative.removeFieldFlags(key, PartialNative.ACC_PUBLIC, key.modifiers)
            is Member -> PartialNative.removeMethodFlags(key, PartialNative.ACC_PUBLIC, key.modifiers)
        }
    }
}
