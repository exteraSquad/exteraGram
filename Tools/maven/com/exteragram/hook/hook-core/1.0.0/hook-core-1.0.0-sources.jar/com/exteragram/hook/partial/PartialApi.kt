/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.partial

import java.lang.reflect.Method

enum class AccessStrategy {
    NONE,
    SKIP_ACCESS_CHECKS,
    ACCESSOR_BRIDGES,
    SAME_LOADER,
    PUBLICIZE,
}

class PartialGenerationStats internal constructor(
    val origin: String,
    val sourceDexBytes: Int,
    val generatedDexBytes: Int,
    val references: Int,
    val inaccessible: List<String>,
    val bridged: List<String>,
    val siteKinds: List<String>,
    val siteHits: List<Int>,
    val locateNanos: Long,
    val scanNanos: Long,
    val planNanos: Long,
    val patchNanos: Long,
    val loadNanos: Long,
) {
    val totalNanos: Long
        get() = locateNanos + scanNanos + planNanos + patchNanos + loadNanos
}

class PartialGeneration internal constructor(
    val number: Int,
    val target: java.lang.reflect.Member,
    val body: Method,
    internal val invoker: PartialInvoker,
    val strategy: AccessStrategy,
    val stats: PartialGenerationStats,
    internal val keepAlive: Any?,
)
