/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.engine

import com.exteragram.hook.ErrorPolicy
import com.exteragram.hook.HookException
import com.exteragram.hook.HookHandle
import com.exteragram.hook.HookLogger
import com.exteragram.hook.HookTarget
import com.exteragram.hook.Interceptor
import java.lang.reflect.AccessibleObject
import java.lang.reflect.Constructor
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Member
import java.lang.reflect.Method
import java.lang.reflect.Modifier

fun interface PartialInstaller {
    fun install(engine: HookEngine, target: HookTarget, priority: Int, policy: ErrorPolicy, interceptor: Interceptor): HookHandle
}

class HookEngine(
    private val backend: HookBackend,
    private val logger: () -> HookLogger,
) {
    private val lock = Any()
    private val records = HashMap<Member, HookRecord>()
    private var sequence = 0L

    @Volatile
    var partial: PartialInstaller? = null

    @Volatile
    var accelerator: OriginalAccelerator? = null

    fun install(target: HookTarget, priority: Int, policy: ErrorPolicy, interceptor: Interceptor): HookHandle {
        if (target !is HookTarget.Method) {
            val installer = partial ?: throw HookException.Unsupported(target.member, "partial hooks are not available")
            return installer.install(this, target, priority, policy, interceptor)
        }
        val member = validate(target)
        synchronized(lock) {
            val entry = Entry(interceptor, priority, sequence++, policy)
            records[member]?.let { existing ->
                existing.add(entry)
                syncDirect(existing)
                return Handle(this, existing, entry)
            }
            val record = installRecord(target, member, entry)
            return Handle(this, record, entry)
        }
    }

    internal fun pin(member: Member, terminal: Terminal, direct: DirectEntry? = null) {
        val target = HookTarget.Method(member)
        validate(target)
        synchronized(lock) {
            val record = records[member] ?: installRecord(target, member, null)
            record.terminal = terminal
            record.direct = direct
            syncDirect(record)
        }
    }

    internal fun unpin(member: Member) {
        synchronized(lock) {
            val record = records[member] ?: return
            record.terminal = null
            record.direct = null
            syncDirect(record)
            if (record.entries.isEmpty()) {
                records.remove(member)
                backend.uninstall(member)
                record.releaseAcceleration()
            }
        }
    }

    internal fun detachedRecord(target: HookTarget, terminal: Terminal): HookRecord =
        HookRecord(target, this).also { it.terminal = terminal }

    internal fun newEntry(interceptor: Interceptor, priority: Int, policy: ErrorPolicy): Entry =
        synchronized(lock) { Entry(interceptor, priority, sequence++, policy) }

    internal fun requireAllowed(member: Member) {
        when (backend.check(member)) {
            TargetVerdict.ALLOWED -> Unit
            TargetVerdict.REFUSED -> throw HookException.Refused(member)
            TargetVerdict.UNAVAILABLE -> throw HookException.Unavailable("native runtime refused to start")
        }
    }

    private fun installRecord(target: HookTarget, member: Member, entry: Entry?): HookRecord {
        requireAllowed(member)
        val record = HookRecord(target, this)
        entry?.let(record::add)
        records[member] = record
        var installed = false
        try {
            val backup = backend.install(Trampoline(record), member) ?: throw HookException.InstallFailed(member)
            record.publishBackup(backup)
            installed = true
        } catch (e: HookException) {
            throw e
        } catch (t: Throwable) {
            throw HookException.InstallFailed(member, t)
        } finally {
            if (!installed) {
                records.remove(member)
                record.markInstallFailed()
            }
        }
        return record
    }

    fun isHooked(member: Member): Boolean = synchronized(lock) { records.containsKey(member) }

    @Throws(Throwable::class)
    fun invokeOriginal(member: Member, thisObject: Any?, args: Array<Any?>, unwrap: Boolean): Any? {
        val record = synchronized(lock) { records[member] }
        if (record != null) {
            return if (unwrap) record.invokeOriginal(thisObject, args) else record.invokeOriginalReflectively(thisObject, args)
        }
        validate(HookTarget.Method(member))
        (member as AccessibleObject).let { if (!it.isAccessible) it.isAccessible = true }
        try {
            return when (member) {
                is Method -> member.invoke(thisObject, *args)
                is Constructor<*> -> member.newInstance(*args)
                else -> throw HookException.Unsupported(member, "not a method or constructor")
            }
        } catch (e: InvocationTargetException) {
            if (!unwrap) throw e
            throw e.cause ?: e
        }
    }

    fun deoptimize(member: Member): Boolean {
        val target = validate(HookTarget.Method(member))
        synchronized(lock) {
            records[member]?.releaseAcceleration()
        }
        return backend.deoptimize(target)
    }

    internal fun remove(record: HookRecord, entry: Entry) {
        synchronized(lock) {
            if (!record.remove(entry)) {
                return
            }
            if (records[record.member] === record) {
                syncDirect(record)
            }
            if (record.entries.isNotEmpty() || record.terminal != null) {
                return
            }
            if (records[record.member] === record) {
                records.remove(record.member)
                backend.uninstall(record.member)
                record.releaseAcceleration()
            }
        }
    }

    private fun syncDirect(record: HookRecord) {
        val wanted = record.direct?.takeIf { record.entries.isEmpty() && record.terminal != null }
        val active = record.activeDirect
        if (wanted === active) {
            return
        }
        try {
            if (wanted != null && wanted.switch(true)) {
                record.activeDirect = wanted
                return
            }
            if (active != null && !active.switch(false)) {
                reportFailure("Cannot return ${record.member} to its hook stub", IllegalStateException("retarget failed"))
            }
        } catch (t: Throwable) {
            reportFailure("Cannot switch the entry point of ${record.member}", t)
        }
        record.activeDirect = null
    }

    internal fun isInstalled(record: HookRecord): Boolean = synchronized(lock) { records[record.member] === record }

    internal fun reportFailure(message: String, throwable: Throwable) {
        try {
            logger().log(message, throwable)
        } catch (_: Throwable) {
        }
    }

    private fun validate(target: HookTarget): Member {
        val member = target.member
        if (member !is Method && member !is Constructor<*>) {
            throw HookException.Unsupported(member, "not a method or constructor")
        }
        if (Modifier.isAbstract((member as Member).modifiers)) {
            throw HookException.Unsupported(member, "abstract methods have no code")
        }
        return member
    }

    private class Handle(
        private val engine: HookEngine,
        private val record: HookRecord,
        private val entry: Entry,
    ) : HookHandle {
        @Volatile
        private var active = true

        override val target: HookTarget get() = record.target

        override val priority: Int get() = entry.priority

        override val isActive: Boolean get() = active && engine.isInstalled(record)

        override fun unhook() {
            if (!active) {
                return
            }
            active = false
            engine.remove(record, entry)
        }
    }
}
