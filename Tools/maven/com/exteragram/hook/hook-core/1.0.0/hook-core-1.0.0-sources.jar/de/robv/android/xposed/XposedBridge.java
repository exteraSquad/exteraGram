/*
 * Originally written by rovo89 as part of the original Xposed
 * Copyright 2013 rovo89, Tungstwenty
 * Licensed under the Apache License, Version 2.0, see http://www.apache.org/licenses/LICENSE-2.0
 *
 * Rewritten by exteraHook as a compatibility layer over com.exteragram.hook.
 * Copyright (c) exteraHook, 2026
 */

package de.robv.android.xposed;

import com.exteragram.hook.ExteraHook;
import com.exteragram.hook.HookException;
import com.exteragram.hook.HookHandle;
import com.exteragram.hook.runtime.Runtimes;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@SuppressWarnings({"unused", "JavaDoc"})
public class XposedBridge {
    private static final Object[] EMPTY_ARRAY = new Object[0];

    private static final Object lock = new Object();
    private static final Map<Member, Map<XC_MethodHook, HookHandle>> hooks = new HashMap<>();

    public static boolean disableProfileSaver() {
        return ExteraHook.getRuntime().disableProfileSaver();
    }

    public static boolean disableHiddenApiRestrictions() {
        return ExteraHook.getRuntime().disableHiddenApiRestrictions();
    }

    /**
     * Check if a method is hooked
     * @param method The method to check
     * @return true if method is hooked
     */
    public static boolean isHooked(Member method) {
        return method != null && ExteraHook.isHooked(method);
    }

    /**
     * Make a final class inheritable. Removes final modifier from class and its constructors and makes
     * constructors accessible (private -> protected)
     *
     * @param clazz Class to make inheritable
     */
    public static boolean makeClassInheritable(Class<?> clazz) {
        if (clazz == null) throw new NullPointerException("class must not be null");
        return ExteraHook.getRuntime().makeClassInheritable(clazz);
    }

    /**
     * Deoptimize a method to avoid inlining
     *
     * @param method The method to deoptimize. Generally it should be a caller of a method
     *               that is inlined.
     */
    public static boolean deoptimizeMethod(Member method) {
        requireHookable(method);
        return ExteraHook.deoptimize(method);
    }

    /**
     * Hook any method (or constructor) with the specified callback.
     *
     * @param method   The method to be hooked.
     * @param callback The callback to be executed when the hooked method is called.
     * @return An object that can be used to remove the hook.
     */
    public static XC_MethodHook.Unhook hookMethod(Member method, XC_MethodHook callback) {
        requireHookable(method);
        if (callback == null) throw new NullPointerException("callback must not be null");

        synchronized (lock) {
            var callbacks = hooks.get(method);
            if (callbacks == null || !callbacks.containsKey(callback)) {
                HookHandle handle;
                try {
                    handle = ExteraHook.hook(method)
                            .priority(callback.priority)
                            .intercept(new XposedInterceptor(callback, method));
                } catch (HookException e) {
                    throw new IllegalStateException("Failed to hook method", e);
                }
                if (callbacks == null) {
                    callbacks = new HashMap<>();
                    hooks.put(method, callbacks);
                }
                callbacks.put(callback, handle);
            }
        }
        return callback.new Unhook(method);
    }

    /**
     * Hooks all methods with a certain name that were declared in the specified class. Inherited
     * methods and constructors are not considered. For constructors, use
     * {@link #hookAllConstructors} instead.
     *
     * @param hookClass  The class to check for declared methods.
     * @param methodName The name of the method(s) to hook.
     * @param callback   The callback to be executed when the hooked methods are called.
     * @return A set containing one object for each found method which can be used to unhook it.
     */
    @SuppressWarnings("UnusedReturnValue")
    public static Set<XC_MethodHook.Unhook> hookAllMethods(Class<?> hookClass, String methodName, XC_MethodHook callback) {
        Set<XC_MethodHook.Unhook> unhooks = new HashSet<>();
        try {
            for (Member method : hookClass.getDeclaredMethods())
                if (method.getName().equals(methodName))
                    unhooks.add(hookMethod(method, callback));
            return unhooks;
        } catch (RuntimeException | Error failure) {
            rollbackHooks(unhooks, failure);
            throw failure;
        }
    }

    /**
     * Hook all constructors of the specified class.
     *
     * @param hookClass The class to check for constructors.
     * @param callback  The callback to be executed when the hooked constructors are called.
     * @return A set containing one object for each found constructor which can be used to unhook it.
     */
    @SuppressWarnings("UnusedReturnValue")
    public static Set<XC_MethodHook.Unhook> hookAllConstructors(Class<?> hookClass, XC_MethodHook callback) {
        Set<XC_MethodHook.Unhook> unhooks = new HashSet<>();
        try {
            for (Member constructor : hookClass.getDeclaredConstructors())
                unhooks.add(hookMethod(constructor, callback));
            return unhooks;
        } catch (RuntimeException | Error failure) {
            rollbackHooks(unhooks, failure);
            throw failure;
        }
    }

    private static void rollbackHooks(Set<XC_MethodHook.Unhook> unhooks, Throwable failure) {
        for (XC_MethodHook.Unhook unhook : unhooks) {
            try {
                unhook.unhook();
            } catch (Throwable rollbackFailure) {
                if (rollbackFailure != failure)
                    failure.addSuppressed(rollbackFailure);
            }
        }
    }

    /**
     * Removes the callback for a hooked method/constructor.
     *
     * @param method   The method for which the callback should be removed.
     * @param callback The reference to the callback as specified in {@link #hookMethod}.
     * @deprecated Use {@link XC_MethodHook.Unhook#unhook} instead. An instance of the {@code Unhook}
     * class is returned when you hook the method.
     */
    @SuppressWarnings("DeprecatedIsStillUsed")
    @Deprecated
    public static void unhookMethod(Member method, XC_MethodHook callback) {
        HookHandle handle;
        synchronized (lock) {
            var callbacks = hooks.get(method);
            if (callbacks == null) {
                return;
            }
            handle = callbacks.remove(callback);
            if (callbacks.isEmpty()) {
                hooks.remove(method);
            }
            if (handle != null) {
                handle.unhook();
            }
        }
    }

    /**
     * Basically the same as {@link Method#invoke}, but calls the original method
     * as it was before the interception by Xposed. Also, access permissions are not checked.
     *
     * @param method     The method to be called.
     * @param thisObject For non-static calls, the "this" pointer, otherwise {@code null}.
     * @param args       Arguments for the method call as Object[] array.
     * @return The result returned from the invoked method.
     * @throws NullPointerException      if {@code receiver == null} for a non-static method
     * @throws IllegalAccessException    if this method is not accessible (see {@link java.lang.reflect.AccessibleObject})
     * @throws IllegalArgumentException  if the number of arguments doesn't match the number of parameters, the receiver
     *                                   is incompatible with the declaring class, or an argument could not be unboxed
     *                                   or converted by a widening conversion to the corresponding parameter type
     * @throws InvocationTargetException if an exception was thrown by the invoked method
     */
    public static Object invokeOriginalMethod(Member method, Object thisObject, Object[] args)
            throws NullPointerException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        if (args == null)
            args = EMPTY_ARRAY;
        if (!ExteraHook.isHooked(method))
            requireHookable(method);
        try {
            return Runtimes.getEngine().invokeOriginal(method, thisObject, args, false);
        } catch (NullPointerException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            throw e;
        } catch (RuntimeException | Error e) {
            throw e;
        } catch (Throwable t) {
            throw new InvocationTargetException(t);
        }
    }

    /**
     * Allocate a class instance without calling any constructors.
     *
     * @param clazz Target class to allocate
     */
    public static <T> T allocateInstance(Class<T> clazz) {
        if (clazz == null) throw new NullPointerException("clazz");
        return ExteraHook.getRuntime().allocateInstance(clazz);
    }

    /**
     * Invoke a constructor for an already existing instance.
     *
     * @param instance    A class instance.
     * @param constructor Constructor located on the instance's class or one of its supertypes.
     * @param args        Args matching the constructor, if any. Can be null.
     * @return True if operation was successful
     */
    public static <S, T extends S> boolean invokeConstructor(T instance, Constructor<S> constructor, Object... args) {
        if (instance == null) throw new NullPointerException("instance");
        if (constructor == null) throw new NullPointerException("constructor");
        if (constructor.isVarArgs()) throw new IllegalArgumentException("varargs parameters are not supported");
        return ExteraHook.getRuntime().invokeConstructor(instance, constructor, args == null ? EMPTY_ARRAY : args);
    }

    private static void requireHookable(Member method) {
        if (method == null)
            throw new NullPointerException("method must not be null");
        if (!(method instanceof Method) && !(method instanceof Constructor<?>))
            throw new IllegalArgumentException("method must be a Method or Constructor");
        if (Modifier.isAbstract(method.getModifiers()))
            throw new IllegalArgumentException("method must not be abstract");
    }

    static void log(Throwable t) {
        Runtimes.log("Uncaught exception in an Xposed callback", t);
    }
}
