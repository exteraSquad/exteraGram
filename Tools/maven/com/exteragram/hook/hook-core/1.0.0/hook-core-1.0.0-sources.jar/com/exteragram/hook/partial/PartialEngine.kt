/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

@file:OptIn(ExperimentalPartialHooks::class)

package com.exteragram.hook.partial

import android.os.Build
import com.exteragram.hook.ErrorPolicy
import com.exteragram.hook.ExperimentalPartialHooks
import com.exteragram.hook.HookException
import com.exteragram.hook.HookHandle
import com.exteragram.hook.HookTarget
import com.exteragram.hook.InstructionMatcher
import com.exteragram.hook.Interceptor
import com.exteragram.hook.engine.DirectEntry
import com.exteragram.hook.engine.Entry
import com.exteragram.hook.engine.HookEngine
import com.exteragram.hook.engine.HookRecord
import com.exteragram.hook.engine.PartialInstaller
import com.exteragram.hook.engine.Terminal
import com.exteragram.hook.runtime.HiddenApi
import com.exteragram.hook.runtime.NativeLibrary
import dalvik.system.BaseDexClassLoader
import dalvik.system.DexClassLoader
import dalvik.system.InMemoryDexClassLoader
import java.io.File
import java.lang.reflect.Constructor
import java.lang.reflect.Field
import java.lang.reflect.Member
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicInteger

internal object PartialEngine : PartialInstaller {
    internal const val GENERATED_PACKAGE = "com.exteragram.hook.partial.gen"

    private val lock = Any()
    private val states = HashMap<Member, MethodState>()
    private val retired = HashMap<HookTarget, Site>()
    private val accessors = HashMap<Pair<Any, String>, Int>()
    private val generations = AtomicInteger()

    override fun install(
        engine: HookEngine,
        target: HookTarget,
        priority: Int,
        policy: ErrorPolicy,
        interceptor: Interceptor,
    ): HookHandle {
        val inMethod = when (target) {
            is HookTarget.CallSite -> target.inMethod
            is HookTarget.FieldAccess -> target.inMethod
            is HookTarget.Instruction -> target.inMethod
            else -> throw HookException.Unsupported(target.member, "this partial hook kind is not implemented")
        }
        if (inMethod !is Method && inMethod !is Constructor<*>) {
            throw HookException.Unsupported(inMethod, "not a method or constructor")
        }
        val callee = target.member
        if (target is HookTarget.CallSite && callee !is Method && callee !is Constructor<*>) {
            throw HookException.Unsupported(callee, "not a method or constructor")
        }
        if (target is HookTarget.Instruction && target.matcher is InstructionMatcher.ReturnValue &&
            returnTypeOf(inMethod) == Void.TYPE
        ) {
            throw HookException.Unsupported(inMethod, "the method returns no value")
        }
        val modifiers = (inMethod as Member).modifiers
        if (Modifier.isAbstract(modifiers) || Modifier.isNative(modifiers)) {
            throw HookException.Unsupported(inMethod, "the method has no bytecode")
        }
        NativeLibrary.ensureLoaded()
        HiddenApi.disable()
        engine.requireAllowed(inMethod)
        engine.requireAllowed(target.member)

        synchronized(lock) {
            val state = states[inMethod] ?: MethodState(engine, inMethod)
            val existing = state.sites.firstOrNull { it.target == target }
            if (existing != null) {
                val entry = engine.newEntry(interceptor, priority, policy)
                existing.record.add(entry)
                return Handle(state, existing, entry, priority)
            }
            val candidate = retired[target] ?: Site(engine, target)
            val overlapping = state.sites.any {
                it.member == candidate.member && it.kind == candidate.kind && it.text == candidate.text &&
                    (it.occurrence == HookTarget.ALL_OCCURRENCES || candidate.occurrence == HookTarget.ALL_OCCURRENCES)
            }
            if (overlapping) {
                throw HookException.Unsupported(inMethod, "sites of ${target.member} overlap with an installed hook")
            }

            val site = candidate
            retired.remove(target)
            state.sites.add(site)
            try {
                state.regenerate()
                engine.pin(inMethod, state.terminal, state.directEntry())
            } catch (t: Throwable) {
                state.sites.remove(site)
                site.useReflection()
                retired[target] = site
                if (state.sites.isEmpty()) {
                    states.remove(inMethod)
                }
                throw when (t) {
                    is HookException -> t
                    is UnsupportedOperationException -> HookException.Unsupported(inMethod, t.message ?: "unsupported")
                    else -> HookException.InstallFailed(inMethod, t)
                }
            }
            states[inMethod] = state
            val entry = engine.newEntry(interceptor, priority, policy)
            site.record.add(entry)
            return Handle(state, site, entry, priority)
        }
    }

    fun generationOf(inMethod: Member): PartialGeneration? = synchronized(lock) { states[inMethod]?.generation }

    fun generationCount(): Int = generations.get()

    private fun release(state: MethodState, site: Site, entry: Entry) {
        synchronized(lock) {
            if (!site.record.remove(entry) || site.record.entries.isNotEmpty()) {
                return
            }
            if (!state.sites.remove(site)) {
                return
            }
            site.useReflection()
            retired[site.target] = site
            if (state.sites.isEmpty()) {
                states.remove(state.inMethod)
                state.generation = null
                state.engine.unpin(state.inMethod)
                return
            }
            try {
                state.regenerate()
                state.engine.pin(state.inMethod, state.terminal, state.directEntry())
            } catch (t: Throwable) {
                state.engine.reportFailure("Cannot regenerate ${state.inMethod} after removing a call-site hook", t)
            }
        }
    }

    private class Site(engine: HookEngine, val target: HookTarget) {
        val member: Member = target.member

        val kind: Char = when (target) {
            is HookTarget.FieldAccess -> if (target.access == HookTarget.FieldAccess.Access.READ) 'R' else 'W'
            is HookTarget.Instruction -> if (target.matcher is InstructionMatcher.ConstString) 'S' else 'X'
            else -> 'M'
        }

        val text: String? = ((target as? HookTarget.Instruction)?.matcher as? InstructionMatcher.ConstString)?.text

        val occurrence: Int = when (target) {
            is HookTarget.CallSite -> target.occurrence
            is HookTarget.FieldAccess -> target.occurrence
            is HookTarget.Instruction -> target.matcher.occurrence
            else -> HookTarget.ALL_OCCURRENCES
        }

        val id: Int = PartialDispatch.reserveCall()

        private val reflective: MemberInvoker = when (kind) {
            'S', 'X' -> MemberInvoker { _, args -> args[0] }
            'R' -> MemberInvokers.fieldGet(member as Field)
            'W' -> MemberInvokers.fieldPut(member as Field)
            else -> if (member is Constructor<*>) MemberInvokers.construct(member) else MemberInvokers.method(member as Method, false)
        }

        private val nonvirtual: MemberInvoker by lazy { MemberInvokers.method(member as Method, true) }

        @Volatile
        var invoker: MemberInvoker = reflective

        fun useReflection() {
            invoker = reflective
        }

        fun useNonvirtual() {
            invoker = nonvirtual
        }

        val record: HookRecord = engine.detachedRecord(target, Terminal { receiver, args -> invoker.invoke(receiver, args) })

        init {
            PartialDispatch.bindCall(id) { caller, receiver, args -> record.run(receiver, args, caller) }
        }
    }

    private class Handle(
        private val state: MethodState,
        private val site: Site,
        private val entry: Entry,
        override val priority: Int,
    ) : HookHandle {
        @Volatile
        private var active = true

        override val target: HookTarget get() = site.target

        override val isActive: Boolean get() = active

        override fun unhook() {
            if (!active) {
                return
            }
            active = false
            release(state, site, entry)
        }
    }

    private class MethodState(val engine: HookEngine, val inMethod: Member) {
        val sites = ArrayList<Site>()

        @Volatile
        var generation: PartialGeneration? = null

        val terminal = Terminal { thisObject, args ->
            val invoker = generation?.invoker ?: return@Terminal engine.invokeOriginal(inMethod, thisObject, args, true)
            invoker.invoke(thisObject, args)
        }

        fun directEntry(): DirectEntry? {
            val current = generation ?: return null
            if (!PartialHooks.directEntry || current.strategy == AccessStrategy.SAME_LOADER || inMethod is Constructor<*>) {
                return null
            }
            val body = current.body
            return DirectEntry { enabled -> PartialNative.retarget(inMethod, if (enabled) body else null) }
        }

        private val owner: Class<*> = inMethod.declaringClass
        private val loader: ClassLoader? = owner.classLoader
        private val ownerDescriptor = Descriptors.of(owner)
        private val signature = Descriptors.signature(parameterTypesOf(inMethod), returnTypeOf(inMethod))

        private var image: DexImage? = null
        private var refs: List<MemberRef> = emptyList()
        private var isStatic = Modifier.isStatic(inMethod.modifiers)

        fun regenerate() {
            val strategy = PartialHooks.accessStrategy

            var mark = System.nanoTime()
            val source = image ?: DexSource.locate(owner).also { image = it }
            val locateNanos = System.nanoTime() - mark

            mark = System.nanoTime()
            if (refs.isEmpty()) {
                val scan = PartialNative.scan(source.buffer, ownerDescriptor, dexNameOf(inMethod), signature)
                isStatic = scan[0] == "static"
                refs = scan.drop(1).map(MemberRef::parse)
            }
            val scanNanos = System.nanoTime() - mark

            mark = System.nanoTime()
            val resolved = AccessPlanner.resolve(refs, loader)
            val signatureTypes = LinkedHashSet<Class<*>>()
            signatureTypes.add(owner)
            signatureTypes.addAll(parameterTypesOf(inMethod))
            signatureTypes.add(returnTypeOf(inMethod))
            val siteSpecs = sites.map { site ->
                if (site.kind == 'S' || site.kind == 'X') {
                    return@map listOf(
                        site.id.toString(), "", site.text?.let(::modifiedUtf8Hex) ?: "", "",
                        site.occurrence.toString(), site.kind.toString(),
                    ).joinToString("\t")
                }
                val member = site.member
                val used = resolved.filter {
                    it.member == member && when (site.kind) {
                        'R' -> it.ref.kind == 'F' && it.ref.op.endsWith("get")
                        'W' -> it.ref.kind == 'F' && it.ref.op.endsWith("put")
                        else -> it.ref.kind == 'M'
                    }
                }
                val owners = used.map { it.ref.owner }.distinct()
                if (owners.isEmpty()) {
                    throw UnsupportedOperationException("$member is not used by $inMethod")
                }
                used.mapNotNullTo(signatureTypes) { it.owner }
                val signature = if (member is Method || member is Constructor<*>) {
                    signatureTypes.addAll(parameterTypesOf(member))
                    signatureTypes.add(if (member is Method) member.returnType else (member as Member).declaringClass)
                    Descriptors.signature(parameterTypesOf(member), returnTypeOf(member))
                } else {
                    signatureTypes.add((member as Field).type)
                    Descriptors.of(member.type)
                }
                listOf(
                    site.id.toString(),
                    owners.joinToString(","),
                    dexNameOf(member),
                    signature,
                    site.occurrence.toString(),
                    site.kind.toString(),
                ).joinToString("\t")
            }
            val inaccessible = resolved.filter { !it.accessible }
            val shielded = strategy == AccessStrategy.PUBLICIZE && !PartialHooks.publishOverridableMethods
            val bridged = resolved.filter {
                val member = it.member
                when {
                    member == null -> false
                    it.ref.kind == 'M' && (it.ref.op == "super" || it.ref.op == "init") -> true
                    inMethod is Constructor<*> && member is Field && it.ref.op.endsWith("put") &&
                        Modifier.isFinal(member.modifiers) -> true
                    shielded && !it.accessible && overridable(member) -> true
                    strategy != AccessStrategy.ACCESSOR_BRIDGES || it.accessible -> false
                    else -> member is Method || member is Field
                }
            }
            if (strategy == AccessStrategy.ACCESSOR_BRIDGES) {
                val uncovered = inaccessible.filter {
                    it.member == null || (it.member is Constructor<*> && it.ref.op != "init")
                }
                if (uncovered.isNotEmpty()) {
                    throw UnsupportedOperationException(
                        "accessor bridges cannot cover " + uncovered.joinToString { it.ref.toString() }
                    )
                }
            }
            val hiddenTypes = signatureTypes.filter { !AccessPlanner.isPublicClass(it) }
            if (strategy == AccessStrategy.ACCESSOR_BRIDGES && hiddenTypes.isNotEmpty()) {
                throw UnsupportedOperationException(
                    "accessor bridges cannot cover " + hiddenTypes.joinToString { it.name }
                )
            }
            val published = ArrayList<Any>()
            try {
                if (strategy == AccessStrategy.PUBLICIZE) {
                    for (ref in resolved) {
                        ref.owner?.let { Publications.acquire(elementOf(it), published) }
                        val member = ref.member as? Member ?: continue
                        Publications.acquire(member.declaringClass, published)
                        if (!(shielded && overridable(ref.member))) {
                            Publications.acquire(member, published)
                        }
                    }
                    signatureTypes.forEach { Publications.acquire(elementOf(it), published) }
                }
                val accessorSpecs = bridged.map { "${accessorId(it)}\t${it.ref.spec}" }
                val planNanos = System.nanoTime() - mark

                val number = generations.incrementAndGet()
                val generatedName = if (strategy == AccessStrategy.SAME_LOADER) {
                    owner.name.substringBeforeLast('.', "").let { if (it.isEmpty()) "" else "$it." } + "ExteraPartial$" + number
                } else {
                    "$GENERATED_PACKAGE.Patched$" + number
                }

                mark = System.nanoTime()
                val siteInfo = arrayOfNulls<String>(sites.size)
                val patched = PartialNative.patch(
                    source.buffer,
                    ownerDescriptor,
                    dexNameOf(inMethod),
                    signature,
                    "L" + generatedName.replace('.', '/') + ";",
                    siteSpecs.toTypedArray(),
                    accessorSpecs.toTypedArray(),
                    siteInfo,
                )
                val patchNanos = System.nanoTime() - mark
                val kinds = siteInfo.map { it!!.substringBefore('\t') }
                val hits = siteInfo.map { it!!.substringAfter('\t').toInt() }

                mark = System.nanoTime()
                val loaded = load(patched, generatedName, loader, strategy)
                val generated = loaded.load(generatedName)
                val keepAlive = loaded.keepAlive
                val body = generated.declaredMethods.first { it.name == "body" }
                val bodyInvoker = loaded.load("$generatedName\$Body").getDeclaredConstructor().newInstance() as PartialInvoker
                val direct = sites.mapIndexed { index, site ->
                    if (site.kind == 'M' && kinds[index] != "super" && directlyCallable(site.member, strategy, shielded)) {
                        loaded.load("$generatedName\$Site${site.id}").getDeclaredConstructor().newInstance() as PartialInvoker
                    } else {
                        null
                    }
                }
                body.isAccessible = true
                Class.forName(generatedName, true, generated.classLoader)
                if (strategy == AccessStrategy.SKIP_ACCESS_CHECKS) {
                    generated.declaredMethods.forEach {
                        check(PartialNative.addMethodFlags(it, PartialNative.ACC_SKIP_ACCESS_CHECKS, it.modifiers)) {
                            "cannot reach the ArtMethod of $it"
                        }
                    }
                }
                sites.forEachIndexed { index, site ->
                    val invoker = direct[index]
                    when {
                        invoker != null -> site.invoker = MemberInvoker { receiver, args -> invoker.invoke(receiver, args) }
                        kinds[index] == "super" -> site.useNonvirtual()
                        else -> site.useReflection()
                    }
                }
                val loadNanos = System.nanoTime() - mark

                generation = PartialGeneration(
                    number = number,
                    target = inMethod,
                    body = body,
                    invoker = bodyInvoker,
                    strategy = strategy,
                    stats = PartialGenerationStats(
                        origin = source.origin,
                        sourceDexBytes = source.buffer.capacity(),
                        generatedDexBytes = patched.size,
                        references = refs.size,
                        inaccessible = inaccessible.map { it.ref.toString() },
                        bridged = bridged.map { it.ref.toString() },
                        siteKinds = kinds,
                        siteHits = hits,
                        locateNanos = locateNanos,
                        scanNanos = scanNanos,
                        planNanos = planNanos,
                        patchNanos = patchNanos,
                        loadNanos = loadNanos,
                    ),
                    keepAlive = keepAlive,
                )
        
                Publications.bind(published, keepAlive)
            } catch (t: Throwable) {
                Publications.release(published)
                throw t
            }
        }

        private fun accessorId(resolved: ResolvedRef): Int = accessors.getOrPut(resolved.member!! to resolved.ref.op) {
            val member = resolved.member
            val target = when {
                member is Constructor<*> -> MemberInvokers.initializer(member)
                member is Method -> MemberInvokers.method(member, resolved.ref.op == "super")
                resolved.ref.op.endsWith("get") -> MemberInvokers.fieldGet(member as Field)
                else -> MemberInvokers.fieldPut(member as Field)
            }
            val id = PartialDispatch.reserveAccessor()
            PartialDispatch.bindAccessor(id) { receiver, args -> target.invoke(receiver, args) }
            id
        }
    }

    private fun modifiedUtf8Hex(text: String): String {
        val bytes = java.io.ByteArrayOutputStream().also { java.io.DataOutputStream(it).writeUTF(text) }.toByteArray()
        return buildString {
            for (i in 2 until bytes.size) {
                append(Character.forDigit((bytes[i].toInt() shr 4) and 0xf, 16))
                append(Character.forDigit(bytes[i].toInt() and 0xf, 16))
            }
        }
    }

    private fun parameterTypesOf(member: Member): Array<Class<*>> = when (member) {
        is Method -> member.parameterTypes
        is Constructor<*> -> member.parameterTypes
        else -> emptyArray()
    }

    private fun returnTypeOf(member: Member): Class<*> = (member as? Method)?.returnType ?: Void.TYPE

    private fun dexNameOf(member: Member): String = if (member is Constructor<*>) "<init>" else member.name

    private fun directlyCallable(callee: Member, strategy: AccessStrategy, shielded: Boolean): Boolean =
        (strategy == AccessStrategy.PUBLICIZE && !(shielded && overridable(callee))) ||
            (Modifier.isPublic(callee.modifiers) && AccessPlanner.isPublicClass(callee.declaringClass))

    private fun overridable(member: Any?): Boolean {
        if (member !is Method) {
            return false
        }
        val modifiers = member.modifiers
        val open = Modifier.PUBLIC or Modifier.PROTECTED or Modifier.PRIVATE or Modifier.STATIC or Modifier.FINAL
        return modifiers and open == 0 && !Modifier.isFinal(member.declaringClass.modifiers)
    }

    private fun elementOf(type: Class<*>): Class<*> {
        var element = type
        while (element.isArray) {
            element = element.componentType!!
        }
        return element
    }

    internal class Loaded(val keepAlive: Any, private val define: (String) -> Class<*>) {
        fun load(name: String): Class<*> = define(name)
    }

    private val legacyDexDirectory: File by lazy {
        val root = File(System.getProperty("java.io.tmpdir"), "exterahook-partial")
        val pid = android.os.Process.myPid().toString()
        root.listFiles()?.forEach { stale ->
            if (stale.name != pid && !File("/proc/${stale.name}").exists()) {
                stale.deleteRecursively()
            }
        }
        File(root, pid).apply {
            deleteRecursively()
            mkdirs()
        }
    }

    internal fun load(image: ByteArray, name: String, parent: ClassLoader?, strategy: AccessStrategy): Loaded {
        if (strategy == AccessStrategy.SAME_LOADER) {
            if (Build.VERSION.SDK_INT < 26) {
                throw UnsupportedOperationException("same-loader injection needs API 26+")
            }
            val carrier = InMemoryDexClassLoader(ByteBuffer.wrap(image), null)
            val pathList = Reflect.field(BaseDexClassLoader::class.java, "pathList").get(carrier)!!
            val element = (Reflect.field(pathList.javaClass, "dexElements").get(pathList) as Array<*>)[0]!!
            val dexFile = Reflect.field(element.javaClass, "dexFile").get(element)!!
            val define = dexFile.javaClass.getDeclaredMethod(
                "loadClassBinaryName", String::class.java, ClassLoader::class.java, List::class.java
            )
            define.isAccessible = true
            retainDex(carrier)
            return Loaded(carrier) { className ->
                val suppressed = ArrayList<Throwable>()
                define.invoke(dexFile, className.replace('.', '/'), parent, suppressed) as Class<*>?
                    ?: throw IllegalStateException("cannot define $className in $parent: $suppressed")
            }
        }
        val loader = if (Build.VERSION.SDK_INT >= 26) {
            InMemoryDexClassLoader(ByteBuffer.wrap(image), parent)
        } else {
            val directory = legacyDexDirectory
            val file = File(directory, "$name.dex")
            file.delete()
            file.writeBytes(image)
            file.setReadOnly()
            val optimized = File(directory, "oat").apply { mkdirs() }
            DexClassLoader(file.absolutePath, optimized.absolutePath, null, parent)
        }
        retainDex(loader)
        return Loaded(loader) { loader.loadClass(it) }
    }

    private fun retainDex(loader: BaseDexClassLoader) {
        try {
            val pathList = Reflect.field(BaseDexClassLoader::class.java, "pathList").get(loader) ?: return
            val elements = Reflect.field(pathList.javaClass, "dexElements").get(pathList) as? Array<*> ?: return
            for (element in elements) {
                val dexFile = Reflect.field(element!!.javaClass, "dexFile").get(element) ?: continue
                Reflect.field(dexFile.javaClass, "mInternalCookie").set(dexFile, null)
            }
        } catch (_: Throwable) {
        }
    }
}
