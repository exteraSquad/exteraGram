/*
 * This is the source code of exteraHook.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright (c) exteraHook, 2026
 */

package com.exteragram.hook.engine

import com.exteragram.hook.Chain
import com.exteragram.hook.ErrorPolicy
import com.exteragram.hook.ExperimentalPartialHooks
import com.exteragram.hook.HookTarget
import java.lang.reflect.Member
import java.util.Collections

@OptIn(ExperimentalPartialHooks::class)
internal class ChainImpl(
    private val record: HookRecord,
    private val entries: Array<Entry>,
    private val index: Int,
    override val thisObject: Any?,
    private val callArgs: Array<Any?>,
    override val caller: Any? = null,
) : Chain {
    private var proceeded = false
    private var lastResult: Any? = null
    private var lastThrowable: Throwable? = null

    override val target: HookTarget get() = record.target

    override val member: Member get() = record.member

    override val args: List<Any?> get() = Collections.unmodifiableList(callArgs.asList())

    override fun arg(index: Int): Any? = callArgs[index]

    override fun proceed(): Any? = proceedWith(thisObject, callArgs)

    override fun proceed(args: Array<Any?>): Any? = proceedWith(thisObject, args)

    override fun proceedWith(thisObject: Any?, args: Array<Any?>): Any? {
        proceeded = true
        try {
            val next = index + 1
            val result = if (next < entries.size) {
                ChainImpl(record, entries, next, thisObject, args.copyOf(), caller).run()
            } else {
                record.proceedTerminal(thisObject, args)
            }
            lastResult = result
            lastThrowable = null
            return result
        } catch (t: Throwable) {
            lastResult = null
            lastThrowable = t
            throw t
        }
    }

    override fun throwToCaller(throwable: Throwable): Nothing = throw DeliberateThrow(throwable)

    fun run(): Any? {
        val entry = entries[index]
        try {
            return record.checkResult(entry.interceptor.intercept(this))
        } catch (t: Throwable) {
            if (t is DeliberateThrow) {
                throw t.throwable
            }
            if (proceeded && t === lastThrowable) {
                throw t
            }
            if (entry.policy == ErrorPolicy.PROPAGATE) {
                throw t
            }
            record.reportInterceptorFailure(entry, t)
            if (!proceeded) {
                return proceed()
            }
            lastThrowable?.let { throw it }
            return lastResult
        }
    }
}

internal class DeliberateThrow(val throwable: Throwable) : RuntimeException(null, null, false, false)
